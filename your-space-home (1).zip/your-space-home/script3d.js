// متغيرات Three.js
let scene, camera, renderer, controls;
let placedModules3D = [];
let currentEnvironmentTheme = 'space';

// متغيرات التحكم في العرض
let showRoofs = true;

// متغيرات التفاعل في العرض ثلاثي الأبعاد
let raycaster = new THREE.Raycaster();
let mouse = new THREE.Vector2();
let gridPlane = null;
let hoveredCell = null;
let isDragging3D = false;
let draggedModuleType = null;
let draggedExistingModule = null;
let dragPreview = null;
let isPointerLocked = false;

// تشغيل العرض ثلاثي الأبعاد عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    setupViewToggle();
    setup3DControls();
});

// إعداد أزرار التبديل بين العروض
function setupViewToggle() {
    const view2DBtn = document.getElementById('view2DBtn');
    const view3DBtn = document.getElementById('view3DBtn');
    const view2D = document.getElementById('view2D');
    const view3D = document.getElementById('view3D');

    view2DBtn.addEventListener('click', function() {
        view2DBtn.classList.add('active');
        view3DBtn.classList.remove('active');
        view2D.style.display = 'block';
        view3D.style.display = 'none';
    });

    view3DBtn.addEventListener('click', function() {
        view3DBtn.classList.add('active');
        view2DBtn.classList.remove('active');
        view2D.style.display = 'none';
        view3D.style.display = 'block';
        
        // بدء العرض ثلاثي الأبعاد
        if (!scene) {
            init3D();
            setupMouseEvents(); // إعداد أحداث الماوس والسحب
        }
        updateEnvironmentTheme();
        
        // تحديث فوري للوحدات عند التبديل إلى 3D
        setTimeout(() => {
            if (typeof placedModules !== 'undefined') {
                update3DModules();
            }
        }, 100);
    });
}

// إعداد أزرار التحكم في العرض ثلاثي الأبعاد
function setup3DControls() {
    const roofToggleBtn = document.getElementById('roofToggleBtn');
    
    // زر تبديل السقف
    roofToggleBtn.addEventListener('click', function() {
        showRoofs = !showRoofs;
        this.classList.toggle('active');
        
        if (showRoofs) {
            this.innerHTML = '<span class="btn-icon">🏠</span><span class="btn-text">إخفاء السقف - Hide Roof</span>';
        } else {
            this.innerHTML = '<span class="btn-icon">🏗️</span><span class="btn-text">إظهار السقف - Show Roof</span>';
        }
        
        // تحديث العرض ثلاثي الأبعاد
        refreshModules3D();
    });
}

// تشغيل الرسم ثلاثي الأبعاد
function init3D() {
    const container = document.getElementById('threejs-container');
    
    // إنشاء المشهد
    scene = new THREE.Scene();
    
    // إنشاء الكاميرا - منظور ثلاثي الأبعاد محسّن
    camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(20, 12, 20);
    camera.lookAt(0, 0, 0);
    
    // إنشاء الراسم
    renderer = new THREE.WebGLRenderer({ 
        antialias: true, 
        alpha: true 
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    container.appendChild(renderer.domElement);
    
    // إعداد التحكم في الكاميرا
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableRotate = true;
    controls.enableZoom = true;
    controls.enablePan = true;
    controls.dampingFactor = 0.1;
    controls.enableDamping = true;
    
    // إعداد الإضاءة المحسّنة - أكثر واقعية ومشرقة
    setupEnhancedLighting();
    
    // إعداد خلفية البيئة
    updateEnvironmentTheme();
    
    // إعداد شبكة التفاعل
    createInteractiveGrid();
    
    // إعداد أحداث الماوس للتفاعل
    setupMouseEvents();
    
    // بدء تشغيل الرسم
    animate();
}

// إعداد الإضاءة المحسّنة
function setupEnhancedLighting() {
    // إضاءة محيطية أقوى وأكثر دفئاً
    const ambientLight = new THREE.AmbientLight(0xf0f0f0, 0.7);
    scene.add(ambientLight);
    
    // إضاءة اتجاهية رئيسية محسّنة
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.0);
    directionalLight.position.set(15, 25, 15);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 4096;
    directionalLight.shadow.mapSize.height = 4096;
    directionalLight.shadow.camera.near = 0.5;
    directionalLight.shadow.camera.far = 80;
    directionalLight.shadow.camera.left = -30;
    directionalLight.shadow.camera.right = 30;
    directionalLight.shadow.camera.top = 30;
    directionalLight.shadow.camera.bottom = -30;
    directionalLight.shadow.bias = -0.0001;
    scene.add(directionalLight);
    
    // إضاءة ملء من الجانب المقابل
    const fillLight = new THREE.DirectionalLight(0xe6f3ff, 0.4);
    fillLight.position.set(-15, 20, -15);
    scene.add(fillLight);
    
    // إضاءة من الأسفل للتفاصيل
    const bottomLight = new THREE.DirectionalLight(0xfff8dc, 0.2);
    bottomLight.position.set(0, -10, 0);
    scene.add(bottomLight);
    
    // إضاءة نقطية محسّنة للتأثيرات الخاصة
    const spotLight = new THREE.SpotLight(0xffffff, 0.5);
    spotLight.position.set(0, 30, 0);
    spotLight.angle = Math.PI / 4;
    spotLight.penumbra = 0.3;
    spotLight.castShadow = true;
    scene.add(spotLight);
}

// تحديث موضوع البيئة والخلفية
function updateEnvironmentTheme() {
    if (!scene) return;
    
    // مسح الخلفية السابقة
    if (scene.background) {
        scene.background = null;
    }
    
    // إزالة الكائنات البيئية السابقة
    const environmentObjects = scene.children.filter(child => 
        child.userData && child.userData.isEnvironmentObject
    );
    environmentObjects.forEach(obj => scene.remove(obj));
    
    switch(currentEnvironment) {
        case 'space':
            createSpaceEnvironment();
            break;
        case 'mars':
            createMarsEnvironment();
            break;
        case 'moon':
            createMoonEnvironment();
            break;
    }
    
    // تحديث العرض ثلاثي الأبعاد للوحدات
    update3DModules();
}

// إنشاء بيئة الفضاء
function createSpaceEnvironment() {
    // خلفية فضائية عميقة
    scene.background = new THREE.Color(0x000011);
    
    // إضافة نجوم متدرجة الأحجام
    const starsGeometry = new THREE.BufferGeometry();
    const starsCount = 2000;
    const positions = new Float32Array(starsCount * 3);
    const colors = new Float32Array(starsCount * 3);
    const sizes = new Float32Array(starsCount);
    
    for (let i = 0; i < starsCount; i++) {
        positions[i * 3] = (Math.random() - 0.5) * 400;
        positions[i * 3 + 1] = (Math.random() - 0.5) * 400;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 400;
        
        // ألوان متنوعة للنجوم
        const starColor = new THREE.Color();
        starColor.setHSL(Math.random() * 0.1 + 0.55, 0.5, 0.7 + Math.random() * 0.3);
        colors[i * 3] = starColor.r;
        colors[i * 3 + 1] = starColor.g;
        colors[i * 3 + 2] = starColor.b;
        
        sizes[i] = Math.random() * 3 + 1;
    }
    
    starsGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    starsGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    starsGeometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
    
    const starsMaterial = new THREE.PointsMaterial({ 
        vertexColors: true,
        size: 2,
        sizeAttenuation: false,
        transparent: true,
        opacity: 0.8
    });
    const stars = new THREE.Points(starsGeometry, starsMaterial);
    stars.userData.isEnvironmentObject = true;
    scene.add(stars);
    
    // محطة فضائية معدنية أكبر وأكثر تفصيلاً
    const platformGeometry = new THREE.BoxGeometry(35, 0.4, 35);
    const platformMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x666666,
        shininess: 80,
        reflectivity: 0.4,
        metalness: 0.7
    });
    const platform = new THREE.Mesh(platformGeometry, platformMaterial);
    platform.position.y = -1.2;
    platform.receiveShadow = true;
    platform.userData.isEnvironmentObject = true;
    scene.add(platform);
    
    // إضافة تفاصيل للمنصة
    for (let i = -3; i <= 3; i++) {
        for (let j = -3; j <= 3; j++) {
            const detailGeometry = new THREE.BoxGeometry(4, 0.1, 4);
            const detailMaterial = new THREE.MeshPhongMaterial({ 
                color: 0x777777,
                shininess: 60
            });
            const detail = new THREE.Mesh(detailGeometry, detailMaterial);
            detail.position.set(i * 5, -0.95, j * 5);
            detail.receiveShadow = true;
            detail.userData.isEnvironmentObject = true;
            scene.add(detail);
        }
    }
    
    // خطوط إرشادية على المنصة
    for (let i = 0; i < 5; i++) {
        const lineGeometry = new THREE.BoxGeometry(25, 0.02, 0.1);
        const lineMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x00ffff,
            emissive: 0x003333
        });
        const line = new THREE.Mesh(lineGeometry, lineMaterial);
        line.position.set(0, -0.85, -10 + i * 5);
        line.userData.isEnvironmentObject = true;
        scene.add(line);
    }
}

// إنشاء بيئة المريخ
function createMarsEnvironment() {
    // خلفية المريخ مع تدرج لوني
    scene.background = new THREE.Color(0xCC5500);
    
    // أرضية المريخ الصحراوية
    const groundGeometry = new THREE.PlaneGeometry(60, 60, 32, 32);
    const groundMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xCD853F,
        shininess: 5
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -1;
    ground.receiveShadow = true;
    ground.userData.isEnvironmentObject = true;
    scene.add(ground);
    
    // كثبان رملية
    for (let i = 0; i < 8; i++) {
        const duneGeometry = new THREE.SphereGeometry(3 + Math.random() * 2, 16, 8);
        const duneMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xDEB887,
            shininess: 2
        });
        const dune = new THREE.Mesh(duneGeometry, duneMaterial);
        dune.position.set(
            (Math.random() - 0.5) * 50,
            -2,
            (Math.random() - 0.5) * 50
        );
        dune.scale.set(1, 0.3, 1);
        dune.receiveShadow = true;
        dune.userData.isEnvironmentObject = true;
        scene.add(dune);
    }
    
    // صخور المريخ بأشكال وأحجام مختلفة
    for (let i = 0; i < 15; i++) {
        const rockSize = 0.3 + Math.random() * 1.2;
        const rockGeometry = new THREE.DodecahedronGeometry(rockSize, 0);
        const rockMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x8B4513,
            shininess: 10
        });
        const rock = new THREE.Mesh(rockGeometry, rockMaterial);
        rock.position.set(
            (Math.random() - 0.5) * 40,
            -0.8 + rockSize * 0.3,
            (Math.random() - 0.5) * 40
        );
        rock.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );
        rock.castShadow = true;
        rock.receiveShadow = true;
        rock.userData.isEnvironmentObject = true;
        scene.add(rock);
    }
    
    // جبال بعيدة
    for (let i = 0; i < 5; i++) {
        const mountainGeometry = new THREE.ConeGeometry(8 + Math.random() * 5, 15 + Math.random() * 10, 8);
        const mountainMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x654321,
            shininess: 1
        });
        const mountain = new THREE.Mesh(mountainGeometry, mountainMaterial);
        mountain.position.set(
            (Math.random() - 0.5) * 100,
            0,
            -30 - Math.random() * 20
        );
        mountain.userData.isEnvironmentObject = true;
        scene.add(mountain);
    }
}

// إنشاء بيئة القمر
function createMoonEnvironment() {
    // خلفية القمر مع نجوم
    scene.background = new THREE.Color(0x0D0D0D);
    
    // سطح القمر مع تفاصيل
    const groundGeometry = new THREE.PlaneGeometry(70, 70, 64, 64);
    const groundMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xC0C0C0,
        shininess: 8
    });
    
    // إضافة تضاريس للسطح
    const vertices = groundGeometry.attributes.position.array;
    for (let i = 0; i < vertices.length; i += 3) {
        vertices[i + 2] += (Math.random() - 0.5) * 0.5;
    }
    groundGeometry.attributes.position.needsUpdate = true;
    groundGeometry.computeVertexNormals();
    
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -1;
    ground.receiveShadow = true;
    ground.userData.isEnvironmentObject = true;
    scene.add(ground);
    
    // حفر القمر بأشكال واقعية
    for (let i = 0; i < 12; i++) {
        const craterSize = 0.8 + Math.random() * 3;
        const craterGeometry = new THREE.CylinderGeometry(
            craterSize, 
            craterSize * 1.2, 
            0.2 + Math.random() * 0.3, 
            24
        );
        const craterMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x999999,
            shininess: 5
        });
        const crater = new THREE.Mesh(craterGeometry, craterMaterial);
        crater.position.set(
            (Math.random() - 0.5) * 50,
            -1.3,
            (Math.random() - 0.5) * 50
        );
        crater.receiveShadow = true;
        crater.userData.isEnvironmentObject = true;
        scene.add(crater);
    }
    
    // صخور قمرية
    for (let i = 0; i < 20; i++) {
        const rockSize = 0.2 + Math.random() * 0.8;
        const rockGeometry = new THREE.IcosahedronGeometry(rockSize, 1);
        const rockMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xB0B0B0,
            shininess: 15
        });
        const rock = new THREE.Mesh(rockGeometry, rockMaterial);
        rock.position.set(
            (Math.random() - 0.5) * 60,
            -0.8,
            (Math.random() - 0.5) * 60
        );
        rock.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );
        rock.castShadow = true;
        rock.receiveShadow = true;
        rock.userData.isEnvironmentObject = true;
        scene.add(rock);
    }
    
    // كوكب الأرض أكثر واقعية
    const earthGeometry = new THREE.SphereGeometry(10, 32, 32);
    const earthMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x1E3A8A, // أزرق محيطات أعمق
        shininess: 50,
        transparent: true,
        opacity: 1.0
    });
    const earth = new THREE.Mesh(earthGeometry, earthMaterial);
    earth.position.set(40, 25, -40);
    earth.userData.isEnvironmentObject = true;
    scene.add(earth);
    
    // غلاف جوي للأرض
    const atmosphereGeometry = new THREE.SphereGeometry(10.5, 32, 32);
    const atmosphereMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x87CEEB,
        transparent: true,
        opacity: 0.3,
        side: THREE.BackSide
    });
    const atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
    atmosphere.position.copy(earth.position);
    atmosphere.userData.isEnvironmentObject = true;
    scene.add(atmosphere);
    
    // قارات واقعية على الأرض
    for (let i = 0; i < 6; i++) {
        const continentGeometry = new THREE.SphereGeometry(10.1, 8, 8);
        const continentMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x228B22,
            transparent: true,
            opacity: 0.7
        });
        const continent = new THREE.Mesh(continentGeometry, continentMaterial);
        
        // توزيع القارات بشكل أكثر واقعية
        const angle = (i / 6) * Math.PI * 2;
        const height = Math.sin(i * 0.7) * 0.3;
        continent.position.set(
            earth.position.x + Math.cos(angle) * 0.1,
            earth.position.y + height,
            earth.position.z + Math.sin(angle) * 0.1
        );
        
        // تدوير القارات لشكل أكثر طبيعية
        continent.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );
        continent.scale.set(0.6, 0.4, 0.8); // شكل أكثر واقعية
        continent.userData.isEnvironmentObject = true;
        scene.add(continent);
    }
}

// تحديث الوحدات ثلاثية الأبعاد
function update3DModules() {
    if (!scene) {
        console.log('المشهد ثلاثي الأبعاد غير موجود');
        return;
    }
    
    console.log('تحديث الوحدات ثلاثية الأبعاد، عدد الوحدات:', placedModules?.length || 0);
    
    // مسح الوحدات السابقة
    const oldModules = scene.children.filter(child => 
        child.userData && child.userData.isModule
    );
    oldModules.forEach(module => scene.remove(module));
    console.log('تم مسح', oldModules.length, 'وحدة سابقة');
    
    // التأكد من وجود placedModules
    if (typeof placedModules === 'undefined' || placedModules.length === 0) {
        console.log('لا توجد وحدات لعرضها');
        return;
    }
    
    // إضافة الوحدات الجديدة
    placedModules.forEach((module, index) => {
        console.log('إضافة وحدة:', module.type, 'في الموقع:', module.x, module.y);
        
        const module3D = createModule3D(module.type, index);
        if (module3D) {
            // تحديد موقع الوحدة حسب إحداثيات x,y مباشرة
            let posX, posZ;
            
            if (module.x !== undefined && module.y !== undefined) {
                // استخدام الإحداثيات المباشرة
                posX = (module.x - gridWidth / 2 + 0.5) * 2.5;
                posZ = (module.y - gridHeight / 2 + 0.5) * 2.5;
            } else if (module.cellIndex !== undefined) {
                // حساب الإحداثيات من cellIndex
                const row = Math.floor(module.cellIndex / gridWidth);
                const col = module.cellIndex % gridWidth;
                posX = (col - gridWidth / 2 + 0.5) * 2.5;
                posZ = (row - gridHeight / 2 + 0.5) * 2.5;
            } else {
                console.error('لا يمكن تحديد موقع الوحدة:', module);
                return;
            }
            
            module3D.position.set(posX, 0, posZ);
            module3D.userData.isModule = true;
            module3D.userData.type = module.type;
            module3D.userData.id = module.id;
            
            scene.add(module3D);
            console.log('تم إضافة وحدة ثلاثية الأبعاد في الموقع:', posX, posZ);
        } else {
            console.error('فشل في إنشاء الوحدة ثلاثية الأبعاد:', module.type);
        }
    });
}

// دالة تحديث موحدة للوحدات ثلاثية الأبعاد
function refreshModules3D() {
    // استخدام نفس دالة التحديث الأساسية
    update3DModules();
}

// إنشاء وحدة ثلاثية الأبعاد واقعية
function createModule3D(type, index) {
    const group = new THREE.Group();
    group.userData.isModule = true;
    group.userData.moduleType = type;
    group.userData.moduleIndex = index;
    
    // ألوان الوحدات الواقعية - جميع الوحدات الـ16
    const moduleColors = {
        sleeping: 0xD3D3D3,        // رمادي فاتح 🛏️
        kitchen: 0xF5F5DC,         // بيج فاتح 🍳
        storage: 0xDEB887,         // بني فاتح 📦
        lifesupport: 0xE0E0E0,     // رمادي معدني 💨
        energy: 0x2F4F4F,         // رمادي داكن 🔋
        waste: 0x90EE90,          // أخضر فاتح ♻️
        thermal: 0xFF6B6B,        // أحمر فاتح 🌡️
        communications: 0x87CEEB, // أزرق سماوي 📡
        medical: 0xFFB6C1,        // وردي فاتح 🏥
        exercise: 0xFFA500,       // برتقالي 🏋️
        food: 0x98FB98,           // أخضر زاهي 🌱
        water: 0x00CED1,          // تركوازي 💧
        safety: 0xFF4500,         // أحمر برتقالي 🚨
        recreation: 0xDDA0DD,     // بنفسجي فاتح 🎯
        research: 0xADD8E6,       // أزرق فاتح 🔬
        maintenance: 0xF0E68C     // أصفر كاكي 🔧
    };
    
    // جدران الوحدة مع لون محدد أو افتراضي
    const moduleColor = moduleColors[type] || 0xCCCCCC; // رمادي افتراضي
    createWalls(group, moduleColor);
    
    // أرضية معدنية أكبر وأكثر تفصيلاً
    const floorGeometry = new THREE.BoxGeometry(2.4, 0.15, 2.4);
    const floorMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x909090,
        shininess: 50,
        reflectivity: 0.3,
        metalness: 0.6
    });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.position.y = 0.075;
    floor.receiveShadow = true;
    group.add(floor);
    
    // إضافة شبكة على الأرضية للتفصيل
    const gridLines = [];
    for (let i = -1; i <= 1; i += 0.4) {
        // خطوط أفقية
        const hLineGeometry = new THREE.BoxGeometry(2.2, 0.01, 0.02);
        const hLineMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x606060,
            shininess: 80
        });
        const hLine = new THREE.Mesh(hLineGeometry, hLineMaterial);
        hLine.position.set(0, 0.16, i);
        group.add(hLine);
        
        // خطوط عمودية
        const vLineGeometry = new THREE.BoxGeometry(0.02, 0.01, 2.2);
        const vLineMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x606060,
            shininess: 80
        });
        const vLine = new THREE.Mesh(vLineGeometry, vLineMaterial);
        vLine.position.set(i, 0.16, 0);
        group.add(vLine);
    }
    
    // إضافة أثاث حسب نوع الوحدة - جميع الوحدات الـ16
    switch(type) {
        case 'sleeping':
            addSleepingFurniture(group);
            break;
        case 'kitchen':
            addKitchenFurniture(group);
            break;
        case 'storage':
            addStorageFurniture(group);
            break;
        case 'lifesupport':
            addLifeSupportFurniture(group);
            break;
        case 'energy':
            addEnergyFurniture(group);
            break;
        case 'waste':
            addWasteFurniture(group);
            break;
        case 'thermal':
            addThermalFurniture(group);
            break;
        case 'communications':
            addCommunicationsFurniture(group);
            break;
        case 'medical':
            addMedicalFurniture(group);
            break;
        case 'exercise':
            addExerciseFurniture(group);
            break;
        case 'food':
            addFoodFurniture(group);
            break;
        case 'water':
            addWaterFurniture(group);
            break;
        case 'safety':
            addSafetyFurniture(group);
            break;
        case 'recreation':
            addRecreationFurniture(group);
            break;
        case 'research':
            addResearchFurniture(group);
            break;
        case 'maintenance':
            addMaintenanceFurniture(group);
            break;
        default:
            // للوحدات غير المعرّفة، إضافة أثاث أساسي
            addBasicFurniture(group);
            break;
    }
    
    // إضافة أيقونة نصية فوق الوحدة لتطابق العرض 2D
    addModuleIcon(group, type);
    
    return group;
}

// إضافة أيقونة الوحدة للتطابق مع العرض 2D
function addModuleIcon(group, type) {
    // أيقونات الوحدات (نفسها المستخدمة في العرض 2D)
    const moduleIcons = {
        sleeping: '🛏️',
        kitchen: '🍳', 
        storage: '📦',
        lifesupport: '💨',
        energy: '🔋',
        waste: '♻️',
        thermal: '🌡️',
        communications: '📡',
        medical: '🏥',
        exercise: '🏋️',
        food: '🌱',
        water: '💧',
        safety: '🚨',
        recreation: '🎯',
        research: '🔬',
        maintenance: '🔧'
    };
    
    // إنشاء كائن نصي بالأيقونة
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.width = 128;
    canvas.height = 128;
    
    context.fillStyle = 'rgba(255, 255, 255, 0.9)';
    context.fillRect(0, 0, canvas.width, canvas.height);
    
    context.font = '60px Arial';
    context.fillStyle = 'black';
    context.textAlign = 'center';
    context.fillText(moduleIcons[type] || '❓', canvas.width / 2, canvas.height / 2 + 20);
    
    const texture = new THREE.CanvasTexture(canvas);
    const material = new THREE.MeshBasicMaterial({ 
        map: texture, 
        transparent: true,
        alphaTest: 0.5
    });
    
    const geometry = new THREE.PlaneGeometry(0.6, 0.6);
    const iconMesh = new THREE.Mesh(geometry, material);
    iconMesh.position.set(0, 2.5, 0);
    iconMesh.rotation.x = -Math.PI / 2; // توجيه للأسفل
    
    group.add(iconMesh);
}

// إضافة أثاث أساسي للوحدات غير المحددة
function addBasicFurniture(group) {
    // صندوق أساسي في الوسط
    const boxGeometry = new THREE.BoxGeometry(0.8, 0.8, 0.8);
    const boxMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x666666,
        shininess: 30
    });
    const box = new THREE.Mesh(boxGeometry, boxMaterial);
    box.position.set(0, 0.4, 0);
    box.castShadow = true;
    group.add(box);
}

// إنشاء جدران الوحدة
function createWalls(group, wallColor) {
    const wallMaterial = new THREE.MeshPhongMaterial({ 
        color: wallColor,
        shininess: 40,
        transparent: true,
        opacity: 0.9,
        metalness: 0.2
    });
    
    // جدار خلفي أكبر وأكثر تفصيلاً
    const backWallGeometry = new THREE.BoxGeometry(2.4, 2.2, 0.12);
    const backWall = new THREE.Mesh(backWallGeometry, wallMaterial);
    backWall.position.set(0, 1.1, -1.14);
    backWall.castShadow = true;
    backWall.receiveShadow = true;
    group.add(backWall);
    
    // جدار يساري
    const leftWallGeometry = new THREE.BoxGeometry(0.12, 2.2, 2.4);
    const leftWall = new THREE.Mesh(leftWallGeometry, wallMaterial);
    leftWall.position.set(-1.14, 1.1, 0);
    leftWall.castShadow = true;
    leftWall.receiveShadow = true;
    group.add(leftWall);
    
    // جدار يميني مع نافذة
    const rightWall = new THREE.Mesh(leftWallGeometry, wallMaterial);
    rightWall.position.set(1.14, 1.1, 0);
    rightWall.castShadow = true;
    rightWall.receiveShadow = true;
    group.add(rightWall);
    
    // إضافة نافذة صغيرة للجدار الأيمن
    const windowGeometry = new THREE.BoxGeometry(0.14, 0.6, 0.6);
    const windowMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x87CEEB,
        transparent: true,
        opacity: 0.7,
        shininess: 100
    });
    const window = new THREE.Mesh(windowGeometry, windowMaterial);
    window.position.set(1.14, 1.3, 0.2);
    group.add(window);
    
    // سقف - يظهر فقط إذا كان مطلوباً
    if (showRoofs) {
        const ceilingGeometry = new THREE.BoxGeometry(2.4, 0.12, 2.4);
        const ceiling = new THREE.Mesh(ceilingGeometry, wallMaterial);
        ceiling.position.set(0, 2.22, 0);
        ceiling.castShadow = true;
        ceiling.receiveShadow = true;
        ceiling.userData.isRoof = true;
        group.add(ceiling);
        
        // شرائط إضاءة LED على السقف
        for (let i = -1; i <= 1; i += 0.5) {
            const ledGeometry = new THREE.BoxGeometry(0.04, 0.02, 2.2);
            const ledMaterial = new THREE.MeshPhongMaterial({ 
                color: 0xFFFFFF,
                emissive: 0x333333,
                shininess: 100
            });
            const led = new THREE.Mesh(ledGeometry, ledMaterial);
            led.position.set(i, 2.15, 0);
            led.userData.isRoof = true;
            group.add(led);
        }
    }
}

// أثاث غرفة النوم
function addSleepingFurniture(group) {
    // إطار السرير
    const bedFrameGeometry = new THREE.BoxGeometry(1.3, 0.2, 0.9);
    const bedFrameMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x8B4513,
        shininess: 20
    });
    const bedFrame = new THREE.Mesh(bedFrameGeometry, bedFrameMaterial);
    bedFrame.position.set(0, 0.3, 0.2);
    bedFrame.castShadow = true;
    bedFrame.receiveShadow = true;
    group.add(bedFrame);
    
    // مرتبة
    const mattressGeometry = new THREE.BoxGeometry(1.2, 0.15, 0.8);
    const mattressMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xF5F5F5,
        shininess: 5
    });
    const mattress = new THREE.Mesh(mattressGeometry, mattressMaterial);
    mattress.position.set(0, 0.47, 0.2);
    mattress.castShadow = true;
    mattress.receiveShadow = true;
    group.add(mattress);
    
    // وسادة
    const pillowGeometry = new THREE.BoxGeometry(0.3, 0.1, 0.2);
    const pillowMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x4682B4,
        shininess: 10
    });
    const pillow = new THREE.Mesh(pillowGeometry, pillowMaterial);
    pillow.position.set(-0.3, 0.62, 0.2);
    pillow.castShadow = true;
    group.add(pillow);
    
    // طاولة جانبية
    const nightstandGeometry = new THREE.BoxGeometry(0.3, 0.5, 0.3);
    const nightstandMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x654321,
        shininess: 25
    });
    const nightstand = new THREE.Mesh(nightstandGeometry, nightstandMaterial);
    nightstand.position.set(0.7, 0.35, 0.2);
    nightstand.castShadow = true;
    nightstand.receiveShadow = true;
    group.add(nightstand);
}

// أثاث المطبخ
function addKitchenFurniture(group) {
    // خزانة المطبخ السفلية
    const cabinetGeometry = new THREE.BoxGeometry(1.4, 0.8, 0.6);
    const cabinetMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x8B4513,
        shininess: 30
    });
    const cabinet = new THREE.Mesh(cabinetGeometry, cabinetMaterial);
    cabinet.position.set(-0.1, 0.5, -0.5);
    cabinet.castShadow = true;
    cabinet.receiveShadow = true;
    group.add(cabinet);
    
    // سطح العمل
    const counterGeometry = new THREE.BoxGeometry(1.5, 0.05, 0.65);
    const counterMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2F4F4F,
        shininess: 50
    });
    const counter = new THREE.Mesh(counterGeometry, counterMaterial);
    counter.position.set(-0.1, 0.92, -0.5);
    counter.castShadow = true;
    counter.receiveShadow = true;
    group.add(counter);
    
    // موقد
    const stoveGeometry = new THREE.BoxGeometry(0.4, 0.1, 0.4);
    const stoveMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x1C1C1C,
        shininess: 80
    });
    const stove = new THREE.Mesh(stoveGeometry, stoveMaterial);
    stove.position.set(0.2, 1.0, -0.5);
    stove.castShadow = true;
    group.add(stove);
    
    // ثلاجة
    const fridgeGeometry = new THREE.BoxGeometry(0.5, 1.2, 0.5);
    const fridgeMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xE6E6FA,
        shininess: 60
    });
    const fridge = new THREE.Mesh(fridgeGeometry, fridgeMaterial);
    fridge.position.set(0.6, 0.7, 0.5);
    fridge.castShadow = true;
    fridge.receiveShadow = true;
    group.add(fridge);
}

// أثاث المخزن
function addStorageFurniture(group) {
    // رفوف معدنية
    for (let i = 0; i < 4; i++) {
        const shelfGeometry = new THREE.BoxGeometry(1.5, 0.05, 0.4);
        const shelfMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x708090,
            shininess: 40
        });
        const shelf = new THREE.Mesh(shelfGeometry, shelfMaterial);
        shelf.position.set(0, 0.3 + i * 0.3, 0.6);
        shelf.castShadow = true;
        shelf.receiveShadow = true;
        group.add(shelf);
    }
    
    // دعامات الرفوف
    for (let i = 0; i < 2; i++) {
        const supportGeometry = new THREE.BoxGeometry(0.05, 1.4, 0.05);
        const supportMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x696969,
            shininess: 30
        });
        const support = new THREE.Mesh(supportGeometry, supportMaterial);
        support.position.set(-0.7 + i * 1.4, 0.8, 0.6);
        support.castShadow = true;
        group.add(support);
    }
    
    // صناديق تخزين معدنية
    for (let i = 0; i < 6; i++) {
        const boxGeometry = new THREE.BoxGeometry(0.3, 0.2, 0.3);
        const boxMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x708090,
            shininess: 35
        });
        const box = new THREE.Mesh(boxGeometry, boxMaterial);
        box.position.set(
            -0.6 + (i % 3) * 0.4, 
            0.4 + Math.floor(i / 3) * 0.3, 
            0.6
        );
        box.castShadow = true;
        box.receiveShadow = true;
        group.add(box);
    }
}

// أثاث دعم الحياة
function addLifeSupportFurniture(group) {
    // جهاز تنقية الهواء الرئيسي
    const purifierGeometry = new THREE.CylinderGeometry(0.35, 0.35, 1.2, 24);
    const purifierMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xC0C0C0,
        shininess: 70,
        reflectivity: 0.3
    });
    const purifier = new THREE.Mesh(purifierGeometry, purifierMaterial);
    purifier.position.set(0.4, 0.7, 0.4);
    purifier.castShadow = true;
    purifier.receiveShadow = true;
    group.add(purifier);
    
    // فلتر علوي
    const filterGeometry = new THREE.CylinderGeometry(0.15, 0.15, 0.2, 16);
    const filterMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2F4F4F,
        shininess: 20
    });
    const filter = new THREE.Mesh(filterGeometry, filterMaterial);
    filter.position.set(0.4, 1.4, 0.4);
    filter.castShadow = true;
    group.add(filter);
    
    // خزان المياه مع مؤشر المستوى
    const tankGeometry = new THREE.CylinderGeometry(0.3, 0.3, 1.0, 20);
    const tankMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x4682B4,
        transparent: true,
        opacity: 0.8,
        shininess: 60
    });
    const tank = new THREE.Mesh(tankGeometry, tankMaterial);
    tank.position.set(-0.4, 0.6, 0.4);
    tank.castShadow = true;
    tank.receiveShadow = true;
    group.add(tank);
    
    // قاعدة الخزان
    const tankBaseGeometry = new THREE.CylinderGeometry(0.35, 0.35, 0.1, 20);
    const tankBaseMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x696969,
        shininess: 40
    });
    const tankBase = new THREE.Mesh(tankBaseGeometry, tankBaseMaterial);
    tankBase.position.set(-0.4, 0.15, 0.4);
    tankBase.castShadow = true;
    group.add(tankBase);
    
    // لوحة تحكم متقدمة
    const controlGeometry = new THREE.BoxGeometry(0.8, 1.0, 0.15);
    const controlMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2F2F2F,
        shininess: 50
    });
    const control = new THREE.Mesh(controlGeometry, controlMaterial);
    control.position.set(0, 0.6, -0.75);
    control.castShadow = true;
    control.receiveShadow = true;
    group.add(control);
    
    // شاشة التحكم
    const screenGeometry = new THREE.BoxGeometry(0.5, 0.3, 0.02);
    const screenMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x00FF00,
        emissive: 0x004400,
        shininess: 100
    });
    const screen = new THREE.Mesh(screenGeometry, screenMaterial);
    screen.position.set(0, 0.8, -0.67);
    screen.castShadow = true;
    group.add(screen);
}

// أثاث الطاقة
function addEnergyFurniture(group) {
    // مولد الطاقة الرئيسي
    const generatorGeometry = new THREE.BoxGeometry(1.0, 1.2, 0.8);
    const generatorMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x708090,
        shininess: 40
    });
    const generator = new THREE.Mesh(generatorGeometry, generatorMaterial);
    generator.position.set(0, 0.7, -0.2);
    generator.castShadow = true;
    generator.receiveShadow = true;
    group.add(generator);
    
    // فتحات تهوية على المولد
    for (let i = 0; i < 4; i++) {
        const ventGeometry = new THREE.RingGeometry(0.05, 0.08, 16);
        const ventMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x2F2F2F,
            shininess: 20
        });
        const vent = new THREE.Mesh(ventGeometry, ventMaterial);
        vent.position.set(-0.3 + (i % 2) * 0.6, 0.9 + Math.floor(i / 2) * 0.3, 0.42);
        vent.rotation.x = -Math.PI / 2;
        group.add(vent);
    }
    
    // بطاريات ليثيوم
    for (let i = 0; i < 4; i++) {
        const batteryGeometry = new THREE.BoxGeometry(0.2, 0.6, 0.3);
        const batteryMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x4682B4,
            shininess: 60
        });
        const battery = new THREE.Mesh(batteryGeometry, batteryMaterial);
        battery.position.set(-0.6 + i * 0.4, 0.4, 0.5);
        battery.castShadow = true;
        battery.receiveShadow = true;
        group.add(battery);
        
        // أقطاب البطارية
        const terminalGeometry = new THREE.CylinderGeometry(0.03, 0.03, 0.05, 8);
        const terminalMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xFFD700,
            shininess: 80
        });
        const terminal = new THREE.Mesh(terminalGeometry, terminalMaterial);
        terminal.position.set(-0.6 + i * 0.4, 0.72, 0.5);
        terminal.castShadow = true;
        group.add(terminal);
    }
    
    // لوحة شمسية متقدمة
    const panelGeometry = new THREE.BoxGeometry(1.4, 0.08, 1.0);
    const panelMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x191970,
        shininess: 70,
        reflectivity: 0.4
    });
    const panel = new THREE.Mesh(panelGeometry, panelMaterial);
    panel.position.set(0, 1.9, 0);
    panel.rotation.x = -0.2;
    panel.castShadow = true;
    panel.receiveShadow = true;
    group.add(panel);
    
    // خلايا شمسية على اللوحة
    for (let i = 0; i < 12; i++) {
        const cellGeometry = new THREE.BoxGeometry(0.2, 0.01, 0.15);
        const cellMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x000080,
            shininess: 90
        });
        const cell = new THREE.Mesh(cellGeometry, cellMaterial);
        cell.position.set(
            -0.5 + (i % 4) * 0.25,
            1.95,
            -0.3 + Math.floor(i / 4) * 0.2
        );
        panel.add(cell);
    }
    
    // لوحة تحكم الطاقة
    const controlPanelGeometry = new THREE.BoxGeometry(0.4, 0.6, 0.1);
    const controlPanelMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2F2F2F,
        shininess: 40
    });
    const controlPanel = new THREE.Mesh(controlPanelGeometry, controlPanelMaterial);
    controlPanel.position.set(0.6, 0.4, -0.75);
    controlPanel.castShadow = true;
    group.add(controlPanel);
}

// أثاث إدارة النفايات
function addWasteFurniture(group) {
    // وحدة إعادة التدوير الرئيسية
    const recyclerGeometry = new THREE.BoxGeometry(1.0, 1.4, 0.8);
    const recyclerMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x228B22,
        shininess: 40
    });
    const recycler = new THREE.Mesh(recyclerGeometry, recyclerMaterial);
    recycler.position.set(0, 0.8, -0.3);
    recycler.castShadow = true;
    recycler.receiveShadow = true;
    group.add(recycler);
    
    // فتحات إدخال النفايات
    for (let i = 0; i < 3; i++) {
        const slotGeometry = new THREE.BoxGeometry(0.2, 0.1, 0.05);
        const slotMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x000000,
            shininess: 100
        });
        const slot = new THREE.Mesh(slotGeometry, slotMaterial);
        slot.position.set(-0.3 + i * 0.3, 1.3, 0.12);
        recycler.add(slot);
    }
    
    // خزانات تجميع
    for (let i = 0; i < 2; i++) {
        const tankGeometry = new THREE.CylinderGeometry(0.25, 0.25, 0.8, 16);
        const tankMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x696969,
            shininess: 35
        });
        const tank = new THREE.Mesh(tankGeometry, tankMaterial);
        tank.position.set(-0.6 + i * 1.2, 0.5, 0.5);
        tank.castShadow = true;
        tank.receiveShadow = true;
        group.add(tank);
    }
}

// أثاث التحكم الحراري
function addThermalFurniture(group) {
    // وحدة التحكم المركزية
    const controlUnitGeometry = new THREE.BoxGeometry(1.2, 1.0, 0.6);
    const controlUnitMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x4682B4,
        shininess: 50
    });
    const controlUnit = new THREE.Mesh(controlUnitGeometry, controlUnitMaterial);
    controlUnit.position.set(0, 0.6, 0);
    controlUnit.castShadow = true;
    controlUnit.receiveShadow = true;
    group.add(controlUnit);
    
    // مبادلات حرارية
    for (let i = 0; i < 4; i++) {
        const exchangerGeometry = new THREE.CylinderGeometry(0.08, 0.08, 0.6, 12);
        const exchangerMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xC0C0C0,
            shininess: 70
        });
        const exchanger = new THREE.Mesh(exchangerGeometry, exchangerMaterial);
        exchanger.position.set(
            -0.4 + (i % 2) * 0.8,
            1.4,
            -0.6 + Math.floor(i / 2) * 0.4
        );
        exchanger.castShadow = true;
        group.add(exchanger);
    }
    
    // أنابيب التوصيل
    for (let i = 0; i < 6; i++) {
        const pipeGeometry = new THREE.CylinderGeometry(0.03, 0.03, 0.8, 8);
        const pipeMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x708090,
            shininess: 60
        });
        const pipe = new THREE.Mesh(pipeGeometry, pipeMaterial);
        pipe.position.set(
            -0.5 + (i % 3) * 0.5,
            0.5,
            0.4
        );
        pipe.rotation.z = Math.PI / 2;
        pipe.castShadow = true;
        group.add(pipe);
    }
}

// أثاث الاتصالات
function addCommunicationsFurniture(group) {
    // هوائي القمر الصناعي
    const dishGeometry = new THREE.SphereGeometry(0.8, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2);
    const dishMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xE6E6FA,
        shininess: 80,
        side: THREE.DoubleSide
    });
    const dish = new THREE.Mesh(dishGeometry, dishMaterial);
    dish.position.set(0, 1.8, 0);
    dish.rotation.x = -Math.PI / 4;
    dish.castShadow = true;
    dish.receiveShadow = true;
    group.add(dish);
    
    // قاعدة الهوائي
    const baseGeometry = new THREE.CylinderGeometry(0.1, 0.15, 0.8, 12);
    const baseMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x708090,
        shininess: 40
    });
    const base = new THREE.Mesh(baseGeometry, baseMaterial);
    base.position.set(0, 0.5, 0);
    base.castShadow = true;
    group.add(base);
    
    // معدات الراديو
    const radioGeometry = new THREE.BoxGeometry(0.6, 0.4, 0.3);
    const radioMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2F2F2F,
        shininess: 30
    });
    const radio = new THREE.Mesh(radioGeometry, radioMaterial);
    radio.position.set(0.5, 0.3, -0.6);
    radio.castShadow = true;
    radio.receiveShadow = true;
    group.add(radio);
    
    // شاشة المراقبة
    const screenGeometry = new THREE.BoxGeometry(0.4, 0.3, 0.02);
    const screenMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x000080,
        emissive: 0x001122,
        shininess: 100
    });
    const screen = new THREE.Mesh(screenGeometry, screenMaterial);
    screen.position.set(-0.5, 0.6, -0.74);
    screen.castShadow = true;
    group.add(screen);
}

// أثاث الطب
function addMedicalFurniture(group) {
    // سرير الفحص
    const bedGeometry = new THREE.BoxGeometry(1.4, 0.8, 0.6);
    const bedMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xF5F5F5,
        shininess: 20
    });
    const bed = new THREE.Mesh(bedGeometry, bedMaterial);
    bed.position.set(0, 0.5, 0.2);
    bed.castShadow = true;
    bed.receiveShadow = true;
    group.add(bed);
    
    // خزانة الأدوية
    const cabinetGeometry = new THREE.BoxGeometry(0.8, 1.2, 0.4);
    const cabinetMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xFFFFFF,
        shininess: 30
    });
    const cabinet = new THREE.Mesh(cabinetGeometry, cabinetMaterial);
    cabinet.position.set(-0.6, 0.7, -0.6);
    cabinet.castShadow = true;
    cabinet.receiveShadow = true;
    group.add(cabinet);
    
    // معدات طبية
    const equipmentGeometry = new THREE.BoxGeometry(0.4, 0.6, 0.3);
    const equipmentMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x708090,
        shininess: 50
    });
    const equipment = new THREE.Mesh(equipmentGeometry, equipmentMaterial);
    equipment.position.set(0.6, 0.4, -0.5);
    equipment.castShadow = true;
    equipment.receiveShadow = true;
    group.add(equipment);
    
    // مصباح جراحي
    const lampGeometry = new THREE.ConeGeometry(0.2, 0.3, 12);
    const lampMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xFFFFFF,
        shininess: 100
    });
    const lamp = new THREE.Mesh(lampGeometry, lampMaterial);
    lamp.position.set(0, 1.6, 0);
    lamp.castShadow = true;
    group.add(lamp);
}

// أثاث الرياضة
function addExerciseFurniture(group) {
    // جهاز المشي
    const treadmillGeometry = new THREE.BoxGeometry(1.2, 0.2, 0.6);
    const treadmillMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2F2F2F,
        shininess: 40
    });
    const treadmill = new THREE.Mesh(treadmillGeometry, treadmillMaterial);
    treadmill.position.set(0, 0.2, 0);
    treadmill.castShadow = true;
    treadmill.receiveShadow = true;
    group.add(treadmill);
    
    // مقابض الجهاز
    for (let i = 0; i < 2; i++) {
        const handleGeometry = new THREE.CylinderGeometry(0.03, 0.03, 0.8, 8);
        const handleMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xC0C0C0,
            shininess: 60
        });
        const handle = new THREE.Mesh(handleGeometry, handleMaterial);
        handle.position.set(-0.5 + i * 1.0, 0.8, -0.2);
        handle.castShadow = true;
        group.add(handle);
    }
    
    // أوزان
    for (let i = 0; i < 4; i++) {
        const weightGeometry = new THREE.CylinderGeometry(0.1, 0.1, 0.05, 12);
        const weightMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x4682B4,
            shininess: 70
        });
        const weight = new THREE.Mesh(weightGeometry, weightMaterial);
        weight.position.set(
            -0.6 + (i % 2) * 1.2,
            0.1,
            0.6 + Math.floor(i / 2) * 0.2
        );
        weight.castShadow = true;
        weight.receiveShadow = true;
        group.add(weight);
    }
    
    // دراجة ثابتة
    const bikeGeometry = new THREE.BoxGeometry(0.6, 0.8, 0.4);
    const bikeMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xFF6B6B,
        shininess: 30
    });
    const bike = new THREE.Mesh(bikeGeometry, bikeMaterial);
    bike.position.set(0.5, 0.5, 0.4);
    bike.castShadow = true;
    bike.receiveShadow = true;
    group.add(bike);
}

// أثاث إنتاج الطعام والزراعة
function addFoodFurniture(group) {
    // نظام الزراعة المائية
    const hydroGeometry = new THREE.BoxGeometry(1.5, 0.3, 0.8);
    const hydroMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2E8B57,
        shininess: 30
    });
    const hydro = new THREE.Mesh(hydroGeometry, hydroMaterial);
    hydro.position.set(0, 0.2, 0);
    hydro.castShadow = true;
    hydro.receiveShadow = true;
    group.add(hydro);
    
    // النباتات
    for (let i = 0; i < 8; i++) {
        const plantGeometry = new THREE.ConeGeometry(0.08, 0.25, 8);
        const plantMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x228B22,
            shininess: 10
        });
        const plant = new THREE.Mesh(plantGeometry, plantMaterial);
        plant.position.set(
            -0.6 + (i % 4) * 0.4,
            0.5,
            -0.2 + Math.floor(i / 4) * 0.4
        );
        plant.castShadow = true;
        group.add(plant);
    }
    
    // مصابيح النمو
    for (let i = 0; i < 2; i++) {
        const lightGeometry = new THREE.CylinderGeometry(0.1, 0.05, 0.4, 12);
        const lightMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xFFFFFF,
            emissive: 0x221122,
            shininess: 80
        });
        const growLight = new THREE.Mesh(lightGeometry, lightMaterial);
        growLight.position.set(-0.3 + i * 0.6, 1.5, 0);
        growLight.castShadow = true;
        group.add(growLight);
    }
    
    // خزان المغذيات
    const tankGeometry = new THREE.CylinderGeometry(0.2, 0.2, 0.6, 16);
    const tankMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x4169E1,
        shininess: 60
    });
    const nutrientTank = new THREE.Mesh(tankGeometry, tankMaterial);
    nutrientTank.position.set(0.6, 0.4, -0.5);
    nutrientTank.castShadow = true;
    nutrientTank.receiveShadow = true;
    group.add(nutrientTank);
}

// أثاث إدارة المياه
function addWaterFurniture(group) {
    // خزان المياه الرئيسي
    const mainTankGeometry = new THREE.CylinderGeometry(0.6, 0.6, 1.2, 16);
    const mainTankMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x4682B4,
        shininess: 70
    });
    const mainTank = new THREE.Mesh(mainTankGeometry, mainTankMaterial);
    mainTank.position.set(0, 0.7, 0);
    mainTank.castShadow = true;
    mainTank.receiveShadow = true;
    group.add(mainTank);
    
    // مرشحات المياه
    for (let i = 0; i < 3; i++) {
        const filterGeometry = new THREE.CylinderGeometry(0.1, 0.1, 0.8, 12);
        const filterMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xC0C0C0,
            shininess: 50
        });
        const filter = new THREE.Mesh(filterGeometry, filterMaterial);
        filter.position.set(
            -0.4 + i * 0.4,
            0.5,
            0.7
        );
        filter.castShadow = true;
        group.add(filter);
    }
    
    // أنابيب التوصيل
    for (let i = 0; i < 4; i++) {
        const pipeGeometry = new THREE.CylinderGeometry(0.03, 0.03, 1.0, 8);
        const pipeMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x708090,
            shininess: 40
        });
        const pipe = new THREE.Mesh(pipeGeometry, pipeMaterial);
        pipe.position.set(
            -0.5 + i * 0.33,
            1.0,
            -0.6
        );
        pipe.rotation.z = Math.PI / 2;
        pipe.castShadow = true;
        group.add(pipe);
    }
    
    // مضخة المياه
    const pumpGeometry = new THREE.BoxGeometry(0.4, 0.3, 0.3);
    const pumpMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2F2F2F,
        shininess: 60
    });
    const pump = new THREE.Mesh(pumpGeometry, pumpMaterial);
    pump.position.set(-0.5, 0.3, -0.5);
    pump.castShadow = true;
    pump.receiveShadow = true;
    group.add(pump);
}

// أثاث الأمان والطوارئ
function addSafetyFurniture(group) {
    // طفايات الحريق
    for (let i = 0; i < 4; i++) {
        const extinguisherGeometry = new THREE.CylinderGeometry(0.08, 0.08, 0.6, 12);
        const extinguisherMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xFF0000,
            shininess: 80
        });
        const extinguisher = new THREE.Mesh(extinguisherGeometry, extinguisherMaterial);
        extinguisher.position.set(
            -0.6 + (i % 2) * 1.2,
            0.4,
            -0.6 + Math.floor(i / 2) * 1.2
        );
        extinguisher.castShadow = true;
        group.add(extinguisher);
    }
    
    // صندوق الإسعافات الأولية
    const firstAidGeometry = new THREE.BoxGeometry(0.4, 0.3, 0.2);
    const firstAidMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xFFFFFF,
        shininess: 40
    });
    const firstAid = new THREE.Mesh(firstAidGeometry, firstAidMaterial);
    firstAid.position.set(0, 0.9, -0.7);
    firstAid.castShadow = true;
    firstAid.receiveShadow = true;
    group.add(firstAid);
    
    // إضافة الصليب الأحمر
    const crossGeometry = new THREE.BoxGeometry(0.05, 0.2, 0.01);
    const crossMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xFF0000,
        shininess: 100
    });
    const cross1 = new THREE.Mesh(crossGeometry, crossMaterial);
    cross1.position.set(0, 0.9, -0.59);
    firstAid.add(cross1);
    
    const cross2 = new THREE.Mesh(crossGeometry, crossMaterial);
    cross2.rotation.z = Math.PI / 2;
    cross2.position.set(0, 0.9, -0.59);
    firstAid.add(cross2);
    
    // أجهزة إنذار الدخان
    for (let i = 0; i < 2; i++) {
        const alarmGeometry = new THREE.CylinderGeometry(0.1, 0.1, 0.05, 16);
        const alarmMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xFFFFFF,
            shininess: 60
        });
        const alarm = new THREE.Mesh(alarmGeometry, alarmMaterial);
        alarm.position.set(-0.4 + i * 0.8, 1.8, 0);
        alarm.castShadow = true;
        group.add(alarm);
    }
    
    // معدات الإخلاء
    const escapeGeometry = new THREE.BoxGeometry(0.3, 0.8, 0.2);
    const escapeMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x32CD32,
        shininess: 30
    });
    const escapeKit = new THREE.Mesh(escapeGeometry, escapeMaterial);
    escapeKit.position.set(0.6, 0.5, 0.4);
    escapeKit.castShadow = true;
    escapeKit.receiveShadow = true;
    group.add(escapeKit);
}

// أثاث الترفيه والاستجمام
function addRecreationFurniture(group) {
    // منطقة الجلوس المريحة
    const sofaGeometry = new THREE.BoxGeometry(1.2, 0.6, 0.6);
    const sofaMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x8B4513,
        shininess: 20
    });
    const sofa = new THREE.Mesh(sofaGeometry, sofaMaterial);
    sofa.position.set(0, 0.4, -0.2);
    sofa.castShadow = true;
    sofa.receiveShadow = true;
    group.add(sofa);
    
    // شاشة ترفيهية كبيرة
    const screenGeometry = new THREE.BoxGeometry(0.8, 0.6, 0.05);
    const screenMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x000000,
        emissive: 0x002222,
        shininess: 100
    });
    const screen = new THREE.Mesh(screenGeometry, screenMaterial);
    screen.position.set(0, 1.0, -0.75);
    screen.castShadow = true;
    group.add(screen);
    
    // مكتبة صغيرة
    const bookshelfGeometry = new THREE.BoxGeometry(0.6, 1.2, 0.3);
    const bookshelfMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x8B4513,
        shininess: 25
    });
    const bookshelf = new THREE.Mesh(bookshelfGeometry, bookshelfMaterial);
    bookshelf.position.set(-0.6, 0.7, 0.5);
    bookshelf.castShadow = true;
    bookshelf.receiveShadow = true;
    group.add(bookshelf);
    
    // كتب على الرف
    for (let i = 0; i < 8; i++) {
        const bookGeometry = new THREE.BoxGeometry(0.03, 0.15, 0.1);
        const bookColors = [0xFF6B6B, 0x4ECDC4, 0x45B7D1, 0x96CEB4, 0xFECA57, 0xFF9FF3, 0x54A0FF, 0x5F27CD];
        const bookMaterial = new THREE.MeshPhongMaterial({ 
            color: bookColors[i],
            shininess: 30
        });
        const book = new THREE.Mesh(bookGeometry, bookMaterial);
        book.position.set(
            -0.75 + (i % 4) * 0.08,
            0.9 + Math.floor(i / 4) * 0.2,
            0.6
        );
        book.castShadow = true;
        bookshelf.add(book);
    }
    
    // طاولة ألعاب
    const gameTableGeometry = new THREE.CylinderGeometry(0.3, 0.3, 0.6, 16);
    const gameTableMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x654321,
        shininess: 40
    });
    const gameTable = new THREE.Mesh(gameTableGeometry, gameTableMaterial);
    gameTable.position.set(0.5, 0.4, 0.3);
    gameTable.castShadow = true;
    gameTable.receiveShadow = true;
    group.add(gameTable);
}

// أثاث البحث والمختبرات
function addResearchFurniture(group) {
    // منضدة المختبر
    const benchGeometry = new THREE.BoxGeometry(1.6, 0.8, 0.8);
    const benchMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xE6E6E6,
        shininess: 70
    });
    const bench = new THREE.Mesh(benchGeometry, benchMaterial);
    bench.position.set(0, 0.5, -0.1);
    bench.castShadow = true;
    bench.receiveShadow = true;
    group.add(bench);
    
    // مجهر
    const microscopeGeometry = new THREE.CylinderGeometry(0.1, 0.15, 0.3, 16);
    const microscopeMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2F2F2F,
        shininess: 80
    });
    const microscope = new THREE.Mesh(microscopeGeometry, microscopeMaterial);
    microscope.position.set(-0.4, 1.1, 0);
    microscope.castShadow = true;
    group.add(microscope);
    
    // حاسوب البحث
    const computerGeometry = new THREE.BoxGeometry(0.3, 0.4, 0.2);
    const computerMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x708090,
        shininess: 50
    });
    const computer = new THREE.Mesh(computerGeometry, computerMaterial);
    computer.position.set(0.4, 1.1, -0.2);
    computer.castShadow = true;
    computer.receiveShadow = true;
    group.add(computer);
    
    // شاشة الحاسوب
    const monitorGeometry = new THREE.BoxGeometry(0.25, 0.2, 0.02);
    const monitorMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x000080,
        emissive: 0x001122,
        shininess: 100
    });
    const monitor = new THREE.Mesh(monitorGeometry, monitorMaterial);
    monitor.position.set(0.4, 1.35, -0.1);
    monitor.castShadow = true;
    group.add(monitor);
    
    // معدات تجارب
    for (let i = 0; i < 4; i++) {
        const equipGeometry = new THREE.CylinderGeometry(0.05, 0.05, 0.15, 12);
        const equipMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xFFD700,
            shininess: 90
        });
        const equip = new THREE.Mesh(equipGeometry, equipMaterial);
        equip.position.set(
            -0.6 + i * 0.2,
            1.0,
            0.2
        );
        equip.castShadow = true;
        group.add(equip);
    }
    
    // خزانة عينات
    const cabinetGeometry = new THREE.BoxGeometry(0.6, 1.0, 0.4);
    const cabinetMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xFFFFFF,
        shininess: 40
    });
    const cabinet = new THREE.Mesh(cabinetGeometry, cabinetMaterial);
    cabinet.position.set(-0.7, 0.6, 0.4);
    cabinet.castShadow = true;
    cabinet.receiveShadow = true;
    group.add(cabinet);
}

// أثاث الصيانة والإصلاح
function addMaintenanceFurniture(group) {
    // منضدة العمل
    const workbenchGeometry = new THREE.BoxGeometry(1.4, 0.8, 0.7);
    const workbenchMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x8B4513,
        shininess: 30
    });
    const workbench = new THREE.Mesh(workbenchGeometry, workbenchMaterial);
    workbench.position.set(0, 0.5, 0);
    workbench.castShadow = true;
    workbench.receiveShadow = true;
    group.add(workbench);
    
    // صندوق الأدوات
    const toolboxGeometry = new THREE.BoxGeometry(0.6, 0.3, 0.4);
    const toolboxMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xFF0000,
        shininess: 60
    });
    const toolbox = new THREE.Mesh(toolboxGeometry, toolboxMaterial);
    toolbox.position.set(-0.4, 1.05, 0);
    toolbox.castShadow = true;
    toolbox.receiveShadow = true;
    group.add(toolbox);
    
    // أدوات متنوعة
    const toolTypes = [
        { geometry: new THREE.CylinderGeometry(0.02, 0.02, 0.4, 8), color: 0xC0C0C0 }, // مفك
        { geometry: new THREE.BoxGeometry(0.25, 0.05, 0.03), color: 0x708090 }, // مفتاح ربط
        { geometry: new THREE.CylinderGeometry(0.04, 0.04, 0.3, 8), color: 0xFFD700 }, // مطرقة
        { geometry: new THREE.BoxGeometry(0.02, 0.3, 0.15), color: 0x2F2F2F } // منشار صغير
    ];
    
    for (let i = 0; i < toolTypes.length; i++) {
        const toolMaterial = new THREE.MeshPhongMaterial({ 
            color: toolTypes[i].color,
            shininess: 70
        });
        const tool = new THREE.Mesh(toolTypes[i].geometry, toolMaterial);
        tool.position.set(
            0.2 + (i % 2) * 0.3,
            1.0,
            -0.2 + Math.floor(i / 2) * 0.4
        );
        tool.rotation.z = Math.random() * Math.PI / 4;
        tool.castShadow = true;
        group.add(tool);
    }
    
    // رف للقطع الغيار
    const shelfGeometry = new THREE.BoxGeometry(0.8, 0.1, 0.3);
    const shelfMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x696969,
        shininess: 40
    });
    const shelf = new THREE.Mesh(shelfGeometry, shelfMaterial);
    shelf.position.set(0.5, 1.4, -0.5);
    shelf.castShadow = true;
    shelf.receiveShadow = true;
    group.add(shelf);
    
    // قطع غيار
    for (let i = 0; i < 6; i++) {
        const partGeometry = new THREE.BoxGeometry(0.08, 0.08, 0.08);
        const partMaterial = new THREE.MeshPhongMaterial({ 
            color: Math.random() * 0xFFFFFF,
            shininess: 50
        });
        const part = new THREE.Mesh(partGeometry, partMaterial);
        part.position.set(
            0.2 + (i % 3) * 0.2,
            1.5,
            -0.6 + Math.floor(i / 3) * 0.2
        );
        part.castShadow = true;
        shelf.add(part);
    }
    
    // جهاز لحام صغير
    const welderGeometry = new THREE.CylinderGeometry(0.05, 0.08, 0.25, 12);
    const welderMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x4169E1,
        shininess: 80
    });
    const welder = new THREE.Mesh(welderGeometry, welderMaterial);
    welder.position.set(-0.6, 1.0, 0.3);
    welder.castShadow = true;
    group.add(welder);
}

// تحديث البيئة ثلاثية الأبعاد عندما تتغير البيئة
function update3DEnvironment(newEnvironment) {
    currentEnvironmentTheme = newEnvironment;
    if (scene) {
        updateEnvironmentTheme();
    }
}

// تحديث العرض ثلاثي الأبعاد - دالة عامة للاستخدام من script.js
window.update3DView = function() {
    if (scene) {
        update3DModules();
    }
};

// تحديث فوري للعرض عند التبديل إلى 3D
window.refresh3DView = function() {
    if (scene && typeof placedModules !== 'undefined') {
        update3DModules();
    }
};

// حلقة الرسم
function animate() {
    requestAnimationFrame(animate);
    
    if (controls) {
        controls.update();
    }
    
    // تحديث التفاعل مع الماوس
    updateMouseInteraction();
    
    if (renderer && scene && camera) {
        renderer.render(scene, camera);
    }
}

// إنشاء شبكة تفاعلية
function createInteractiveGrid() {
    // إزالة الشبكة السابقة إذا كانت موجودة
    if (gridPlane) {
        scene.remove(gridPlane);
        gridPlane = null;
    }
    
    const gridSize = Math.max(gridWidth, gridHeight);
    const cellSize = 2.5;
    
    // إنشاء مستوى الشبكة للتفاعل
    const gridGeometry = new THREE.PlaneGeometry(
        gridSize * cellSize, 
        gridSize * cellSize
    );
    const gridMaterial = new THREE.MeshBasicMaterial({ 
        transparent: true, 
        opacity: 0,
        side: THREE.DoubleSide
    });
    
    gridPlane = new THREE.Mesh(gridGeometry, gridMaterial);
    gridPlane.rotation.x = -Math.PI / 2;
    gridPlane.position.y = -0.9;
    gridPlane.userData.isInteractiveGrid = true;
    scene.add(gridPlane);
}

// تحديث الشبكة التفاعلية عند تغيير الحجم
function updateInteractiveGrid() {
    if (scene) {
        createInteractiveGrid();
    }
}

// إعداد أحداث الماوس واللمس
function setupMouseEvents() {
    const container = document.getElementById('threejs-container');
    if (!container) {
        console.error('لم يتم العثور على عنصر threejs-container');
        return;
    }
    
    console.log('إعداد أحداث الماوس للعرض ثلاثي الأبعاد');
    
    // أحداث الماوس
    container.addEventListener('mousemove', onMouseMove, false);
    container.addEventListener('click', onMouseClick, false);
    container.addEventListener('mousedown', onMouseDown, false);
    container.addEventListener('mouseup', onMouseUp, false);
    container.addEventListener('mouseleave', onMouseLeave, false);
    
    // أحداث اللمس للأجهزة اللوحية
    container.addEventListener('touchstart', onTouchStart, false);
    container.addEventListener('touchmove', onTouchMove, false);
    container.addEventListener('touchend', onTouchEnd, false);
    
    // منع التمرير الافتراضي أثناء اللمس
    container.addEventListener('touchstart', function(e) {
        if (isDragging3D) e.preventDefault();
    }, { passive: false });
    
    container.addEventListener('touchmove', function(e) {
        if (isDragging3D) e.preventDefault();
    }, { passive: false });
    
    // إعداد أحداث سحب الوحدات من الشريط الجانبي
    setupModuleDragEvents();
}

// إعداد أحداث سحب الوحدات
function setupModuleDragEvents() {
    const modules = document.querySelectorAll('.module');
    modules.forEach(module => {
        // إضافة أحداث السحب للوحدات
        module.addEventListener('mousedown', function(e) {
            if (document.getElementById('view3D').style.display === 'block') {
                // منع السحب الافتراضي
                e.preventDefault();
                
                draggedModuleType = this.dataset.type;
                isDragging3D = true;
                createDragPreview(draggedModuleType);
                console.log('بدء سحب وحدة من الشريط:', draggedModuleType);
            }
        });
    });
}

// تحديث موقع الماوس
function onMouseMove(event) {
    const container = document.getElementById('threejs-container');
    if (!container) return;
    
    const rect = container.getBoundingClientRect();
    
    mouse.x = ((event.clientX - rect.left) / container.clientWidth) * 2 - 1;
    mouse.y = -((event.clientY - rect.top) / container.clientHeight) * 2 + 1;
    
    // تحديث التفاعل فقط إذا كان هناك سحب نشط
    if (isDragging3D) {
        updateMouseInteraction();
    }
}

// النقر على الشبكة
function onMouseClick(event) {
    if (isDragging3D) return;
    
    // فحص النقر على وحدة موجودة
    const clickedModule = getClickedModule();
    if (clickedModule) {
        startDragExistingModule(clickedModule);
        return;
    }
    
    // إضافة وحدة جديدة
    const gridPosition = getGridPosition();
    if (gridPosition && draggedModuleType) {
        addModuleAt3D(draggedModuleType, gridPosition.x, gridPosition.z);
        draggedModuleType = null;
        clearDragPreview();
    }
}

// بداية السحب
function onMouseDown(event) {
    // تحقق من أن النقر داخل العرض ثلاثي الأبعاد
    const container = document.getElementById('threejs-container');
    if (!container || !container.contains(event.target)) {
        return;
    }
    
    // فحص إذا كان النقر على وحدة من الشريط الجانبي
    const moduleElement = event.target.closest('.module');
    if (moduleElement && moduleElement.dataset.type) {
        event.preventDefault();
        draggedModuleType = moduleElement.dataset.type;
        isDragging3D = true;
        createDragPreview(draggedModuleType);
        console.log('بدء سحب وحدة:', draggedModuleType);
        return;
    }
    
    // فحص النقر على وحدة موجودة في العرض ثلاثي الأبعاد
    const clickedModule = getClickedModule();
    if (clickedModule) {
        event.preventDefault();
        startDragExistingModule(clickedModule);
        console.log('بدء سحب وحدة موجودة:', clickedModule.type);
    }
}

// انتهاء السحب
function onMouseUp(event) {
    if (isDragging3D) {
        const gridPosition = getGridPosition();
        
        // سحب وحدة جديدة
        if (gridPosition && draggedModuleType) {
            console.log('إضافة وحدة في الموقع:', gridPosition);
            addModuleAt3D(draggedModuleType, gridPosition.x, gridPosition.z);
        }
        
        // سحب وحدة موجودة
        if (gridPosition && draggedExistingModule) {
            console.log('تحريك وحدة موجودة إلى:', gridPosition);
            moveExistingModule3D(draggedExistingModule, gridPosition.x, gridPosition.z);
        }
        
        // تنظيف
        endDrag3D();
    }
}

// انتهاء السحب عند مغادرة المنطقة
function onMouseLeave(event) {
    if (isDragging3D) {
        endDrag3D();
    }
}

// تنظيف انتهاء السحب
function endDrag3D() {
    isDragging3D = false;
    draggedModuleType = null;
    draggedExistingModule = null;
    clearDragPreview();
    clearGridHighlight();
}

// الحصول على موقع الشبكة من موقع الماوس
function getGridPosition() {
    if (!gridPlane) return null;
    
    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObject(gridPlane);
    
    if (intersects.length > 0) {
        const point = intersects[0].point;
        const cellSize = 2.5;
        
        // تحويل الإحداثيات إلى مواقع الشبكة
        const gridX = Math.floor((point.x + (gridWidth * cellSize) / 2) / cellSize);
        const gridZ = Math.floor((point.z + (gridHeight * cellSize) / 2) / cellSize);
        
        // التأكد من أن الموقع داخل حدود الشبكة
        if (gridX >= 0 && gridX < gridWidth && gridZ >= 0 && gridZ < gridHeight) {
            return { x: gridX, z: gridZ };
        }
    }
    
    return null;
}

// الحصول على بيانات الوحدة
function getModuleData(type) {
    const moduleTypes = {
        sleeping: { name: 'غرفة النوم - Sleeping', weight: 50, power: 5, icon: '🛏️' },
        kitchen: { name: 'المطبخ - Kitchen', weight: 80, power: 15, icon: '🍳' },
        storage: { name: 'التخزين - Storage', weight: 30, power: 2, icon: '📦' },
        lifesupport: { name: 'دعم الحياة - Life Support', weight: 100, power: 25, icon: '💨' },
        energy: { name: 'الطاقة - Energy', weight: 120, power: 0, icon: '🔋' },
        waste: { name: 'إدارة النفايات - Waste Management', weight: 60, power: 10, icon: '♻️' },
        thermal: { name: 'التحكم الحراري - Thermal Control', weight: 70, power: 12, icon: '🌡️' },
        communications: { name: 'الاتصالات - Communications', weight: 40, power: 8, icon: '📡' },
        medical: { name: 'المختبر الطبي - Medical Lab', weight: 90, power: 18, icon: '🏥' },
        exercise: { name: 'التمارين الرياضية - Exercise', weight: 75, power: 7, icon: '🏃' },
        food: { name: 'إنتاج الغذاء - Food Production', weight: 85, power: 20, icon: '🌱' },
        water: { name: 'إدارة المياه - Water Management', weight: 95, power: 15, icon: '💧' },
        safety: { name: 'السلامة والطوارئ - Safety & Emergency', weight: 55, power: 6, icon: '🚨' },
        recreation: { name: 'الترفيه والاستجمام - Recreation', weight: 45, power: 8, icon: '🎯' },
        research: { name: 'مختبر البحوث - Research Lab', weight: 110, power: 22, icon: '🔬' },
        maintenance: { name: 'صيانة وإصلاح - Maintenance', weight: 65, power: 12, icon: '🔧' }
    };
    return moduleTypes[type] || null;
}

// إضافة وحدة في موقع محدد في العرض ثلاثي الأبعاد
function addModuleAt3D(type, gridX, gridZ) {
    console.log('محاولة إضافة وحدة:', type, 'في الموقع:', gridX, gridZ);
    
    // التأكد من وجود المصفوفة
    if (typeof placedModules === 'undefined') {
        console.error('placedModules غير معرف');
        return;
    }
    
    // حساب cellIndex (نفس طريقة العرض ثنائي الأبعاد)
    const cellIndex = gridZ * gridWidth + gridX;
    
    // فحص إذا كان الموقع فارغ
    const existingModule = placedModules.find(m => 
        (m.cellIndex === cellIndex) || (m.x === gridX && m.y === gridZ)
    );
    if (existingModule) {
        console.log('الموقع محجوز بالفعل');
        return; 
    }
    
    // الحصول على بيانات الوحدة
    const moduleData = getModuleData(type);
    if (!moduleData) {
        console.error('لم يتم العثور على بيانات الوحدة:', type);
        return;
    }
    
    // إضافة الوحدة بنفس تنسيق العرض ثنائي الأبعاد
    const newModule = {
        type: type,
        x: gridX,
        y: gridZ,
        cellIndex: cellIndex,
        weight: moduleData.weight,
        power: moduleData.power,
        id: `module_${Date.now()}_${Math.random()}`
    };
    
    placedModules.push(newModule);
    console.log('تم إضافة الوحدة:', newModule);
    console.log('عدد الوحدات الحالي:', placedModules.length);
    
    // تحديث العرضين
    update3DModules();
    if (typeof updateGrid === 'function') {
        updateGrid();
    }
    
    // تحديث الإحصائيات
    if (typeof updateStats === 'function') {
        updateStats();
    }
}

// تحديث التفاعل مع الماوس
function updateMouseInteraction() {
    if (!gridPlane) return;
    
    const gridPosition = getGridPosition();
    
    // تحديث معاينة السحب
    if (dragPreview && gridPosition) {
        const cellSize = 2.5;
        dragPreview.position.set(
            (gridPosition.x - gridWidth / 2 + 0.5) * cellSize,
            1.1,
            (gridPosition.z - gridHeight / 2 + 0.5) * cellSize
        );
    }
    
    // إظهار موقع الخلية المحتملة
    if (gridPosition && isDragging3D) {
        highlightGridCell(gridPosition.x, gridPosition.z);
    } else {
        clearGridHighlight();
    }
}

// إبراز خلية الشبكة
function highlightGridCell(gridX, gridZ) {
    // إزالة الإبراز السابق
    clearGridHighlight();
    
    const cellSize = 2.5;
    const highlightGeometry = new THREE.PlaneGeometry(cellSize * 0.9, cellSize * 0.9);
    const highlightMaterial = new THREE.MeshBasicMaterial({ 
        color: 0x00ff00, 
        transparent: true, 
        opacity: 0.3,
        side: THREE.DoubleSide
    });
    
    hoveredCell = new THREE.Mesh(highlightGeometry, highlightMaterial);
    hoveredCell.rotation.x = -Math.PI / 2;
    hoveredCell.position.set(
        (gridX - gridWidth / 2 + 0.5) * cellSize,
        -0.8,
        (gridZ - gridHeight / 2 + 0.5) * cellSize
    );
    hoveredCell.userData.isHighlight = true;
    scene.add(hoveredCell);
}

// إزالة إبراز الشبكة
function clearGridHighlight() {
    if (hoveredCell) {
        scene.remove(hoveredCell);
        hoveredCell = null;
    }
}

// الحصول على الوحدة المنقورة في العرض ثلاثي الأبعاد
function getClickedModule() {
    if (!scene) return null;
    
    raycaster.setFromCamera(mouse, camera);
    
    // البحث عن الوحدات في المشهد
    const modules = scene.children.filter(child => 
        child.userData && child.userData.isModule
    );
    
    const intersects = raycaster.intersectObjects(modules, true);
    
    if (intersects.length > 0) {
        let moduleObject = intersects[0].object;
        
        // البحث عن الكائن الجذري للوحدة
        while (moduleObject.parent && !moduleObject.userData.isModule) {
            moduleObject = moduleObject.parent;
        }
        
        if (moduleObject.userData && moduleObject.userData.isModule) {
            return moduleObject.userData;
        }
    }
    
    return null;
}

// بداية سحب وحدة موجودة
function startDragExistingModule(moduleData) {
    draggedExistingModule = moduleData;
    isDragging3D = true;
    
    // إنشاء معاينة للسحب
    createDragPreview(moduleData.type);
    
    // إخفاء الوحدة الأصلية مؤقتاً
    highlightExistingModule(moduleData, true);
}

// تحريك وحدة موجودة
function moveExistingModule3D(moduleData, newGridX, newGridZ) {
    // فحص إذا كان الموقع الجديد فارغ
    const existingModule = placedModules.find(m => 
        m.x === newGridX && m.y === newGridZ && m.id !== moduleData.id
    );
    
    if (existingModule) {
        return; // الموقع محجوز
    }
    
    // تحديث موقع الوحدة
    const moduleIndex = placedModules.findIndex(m => m.id === moduleData.id);
    if (moduleIndex !== -1) {
        placedModules[moduleIndex].x = newGridX;
        placedModules[moduleIndex].y = newGridZ;
        
        // تحديث العرضين
        update3DModules();
        if (typeof updateGrid === 'function') {
            updateGrid();
        }
        
        // تحديث الإحصائيات
        if (typeof updateStats === 'function') {
            updateStats();
        }
    }
}

// إبراز وحدة موجودة
function highlightExistingModule(moduleData, highlight) {
    if (!scene) return;
    
    const modules = scene.children.filter(child => 
        child.userData && child.userData.isModule && child.userData.id === moduleData.id
    );
    
    modules.forEach(module => {
        if (highlight) {
            module.material.opacity = 0.5;
            module.material.transparent = true;
        } else {
            module.material.opacity = 1.0;
            module.material.transparent = false;
        }
    });
}

// إنشاء معاينة السحب
function createDragPreview(moduleType) {
    clearDragPreview();
    
    // إنشاء نموذج شفاف للمعاينة
    const previewGroup = new THREE.Group();
    
    // إنشاء نموذج مبسط للوحدة
    const geometry = new THREE.BoxGeometry(2.2, 2.2, 2.2);
    const material = new THREE.MeshBasicMaterial({ 
        color: getModuleColor(moduleType), 
        transparent: true, 
        opacity: 0.4,
        wireframe: true
    });
    
    const preview = new THREE.Mesh(geometry, material);
    previewGroup.add(preview);
    
    // إضافة أيقونة
    const iconGeometry = new THREE.PlaneGeometry(1.5, 1.5);
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const context = canvas.getContext('2d');
    context.font = '48px Arial';
    context.textAlign = 'center';
    context.textBaseline = 'middle';
    context.fillText(getModuleIcon(moduleType), 32, 32);
    
    const iconTexture = new THREE.CanvasTexture(canvas);
    const iconMaterial = new THREE.MeshBasicMaterial({ 
        map: iconTexture, 
        transparent: true,
        opacity: 0.8
    });
    
    const icon = new THREE.Mesh(iconGeometry, iconMaterial);
    icon.position.y = 1.2;
    previewGroup.add(icon);
    
    dragPreview = previewGroup;
    dragPreview.userData.isDragPreview = true;
    scene.add(dragPreview);
}

// إزالة معاينة السحب
function clearDragPreview() {
    if (dragPreview) {
        scene.remove(dragPreview);
        dragPreview = null;
    }
}

// الحصول على لون الوحدة
function getModuleColor(type) {
    const colors = {
        sleeping: 0xFF69B4,
        kitchen: 0xFFD700,
        storage: 0x32CD32,
        lifesupport: 0x20B2AA,
        energy: 0xFF8C00,
        waste: 0x9ACD32,
        thermal: 0xFF6347,
        communications: 0x4169E1,
        medical: 0xFF1493,
        exercise: 0x32CD32,
        food: 0x90EE90,
        water: 0x87CEEB,
        safety: 0xFF4500,
        recreation: 0xDDA0DD,
        research: 0x6A5ACD,
        maintenance: 0x708090
    };
    return colors[type] || 0x888888;
}

// الحصول على أيقونة الوحدة
function getModuleIcon(type) {
    const icons = {
        sleeping: '🛏️',
        kitchen: '🍳',
        storage: '📦',
        lifesupport: '💨',
        energy: '🔋',
        waste: '♻️',
        thermal: '🌡️',
        communications: '📡',
        medical: '🏥',
        exercise: '🏃',
        food: '🌱',
        water: '💧',
        safety: '🚨',
        recreation: '🎯',
        research: '🔬',
        maintenance: '🔧'
    };
    return icons[type] || '📦';
}

// أحداث اللمس
function onTouchStart(event) {
    if (event.touches.length === 1) {
        const touch = event.touches[0];
        updateMouseFromTouch(touch);
        onMouseDown(event);
    }
}

function onTouchMove(event) {
    if (event.touches.length === 1) {
        const touch = event.touches[0];
        updateMouseFromTouch(touch);
        onMouseMove(event);
    }
}

function onTouchEnd(event) {
    onMouseUp(event);
}

// تحديث موقع الماوس من اللمس
function updateMouseFromTouch(touch) {
    const container = document.getElementById('threejs-container');
    const rect = container.getBoundingClientRect();
    
    mouse.x = ((touch.clientX - rect.left) / container.clientWidth) * 2 - 1;
    mouse.y = -((touch.clientY - rect.top) / container.clientHeight) * 2 + 1;
}

// تحديث حجم الشاشة
window.addEventListener('resize', function() {
    if (camera && renderer) {
        const container = document.getElementById('threejs-container');
        camera.aspect = container.clientWidth / container.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(container.clientWidth, container.clientHeight);
    }
});