// متغيرات عامة
let placedModules = [];
let draggedElement = null;
let currentEnvironment = 'space';

// معاملات البيئات المختلفة
const environmentParameters = {
    space: {
        name: 'Space - الفضاء',
        gravity: 0,
        weightLimit: Infinity,
        powerFactor: 1.0,
        costFactor: 1.5, // تكلفة نقل متوسطة للفضاء
        survivalBase: 365, // أيام أساسية
        oxygenEfficiency: 1.0,
        powerEfficiency: 1.0
    },
    mars: {
        name: 'Mars - المريخ',
        gravity: 3.7, // م/ث²
        weightLimit: 8000, // كيلوغرام
        powerFactor: 0.4, // طاقة شمسية أقل
        costFactor: 12.0, // تكلفة عالية جداً للنقل للمريخ
        survivalBase: 200,
        oxygenEfficiency: 0.7, // صعوبة في الأكسجين
        powerEfficiency: 0.4
    },
    moon: {
        name: 'Moon - القمر',
        gravity: 1.6, // م/ث²
        weightLimit: 5000, // كيلوغرام
        powerFactor: 0.2, // ليل طويل
        costFactor: 6.5, // تكلفة عالية للنقل للقمر
        survivalBase: 150,
        oxygenEfficiency: 0.5, // صعوبة كبيرة في الأكسجين
        powerEfficiency: 0.2
    }
};

// أيقونات الوحدات
const moduleIcons = {
    sleeping: '🛏️',
    kitchen: '🍳',
    storage: '📦',
    lifesupport: '💨',
    energy: '🔋',
    waste: '♻️',
    thermal: '🌡️',
    communications: '📡',
    medical: '🏥',
    exercise: '🏋️',
    food: '🌱',
    water: '💧',
    safety: '🚨',
    recreation: '🎯',
    research: '🔬',
    maintenance: '🔧'
};

// خصائص الوحدات
const moduleProperties = {
    sleeping: { weight: 500, power: 200, cost: 2500000, required: true, description: 'منطقة الراحة والنوم للطاقم - Sleep and rest area for crew' },
    kitchen: { weight: 800, power: 300, cost: 4200000, required: true, description: 'منطقة إعداد وتناول الطعام - Food preparation and dining area' },
    storage: { weight: 300, power: 50, cost: 800000, required: false, description: 'تخزين المعدات والمواد - Equipment and supplies storage' },
    lifesupport: { weight: 1200, power: 400, cost: 8500000, required: true, description: 'نظام دعم الحياة والأوكسجين - Life support and oxygen systems' },
    energy: { weight: 600, power: -500, cost: 6000000, required: false, description: 'مولدات الطاقة والبطاريات - Power generation and batteries' },
    waste: { weight: 400, power: 150, cost: 3200000, required: false, description: 'نظام إدارة ومعالجة النفايات - Waste management and recycling system' },
    thermal: { weight: 700, power: 250, cost: 4500000, required: false, description: 'نظام التحكم في درجة الحرارة - Temperature control system' },
    communications: { weight: 200, power: 100, cost: 1800000, required: false, description: 'أنظمة الاتصال مع الأرض - Communication systems with Earth' },
    medical: { weight: 350, power: 180, cost: 3500000, required: false, description: 'مرفق طبي وعيادة طوارئ - Medical facility and emergency clinic' },
    exercise: { weight: 250, power: 80, cost: 1200000, required: false, description: 'معدات الرياضة واللياقة - Exercise and fitness equipment' },
    food: { weight: 900, power: 350, cost: 7800000, required: true, description: 'نظام إنتاج الطعام والزراعة المائية - Food production and hydroponic farming system' },
    water: { weight: 800, power: 200, cost: 5500000, required: true, description: 'نظام إدارة ومعالجة المياه - Water management and recycling system' },
    safety: { weight: 300, power: 120, cost: 2800000, required: false, description: 'نظام الأمان والطوارئ والإخلاء - Safety, emergency and evacuation systems' },
    recreation: { weight: 400, power: 100, cost: 1500000, required: false, description: 'منطقة الترفيه والاستجمام الذهني - Recreation and mental wellness area' },
    research: { weight: 600, power: 300, cost: 9200000, required: false, description: 'مختبرات البحث والتجارب العلمية - Research laboratories and scientific experiments' },
    maintenance: { weight: 500, power: 150, cost: 3800000, required: false, description: 'ورشة الصيانة وإصلاح المعدات - Maintenance workshop and equipment repair' }
};

// متغيرات إعداد المسكن
let habitatSize = 'small';
let selectedFunctions = ['waste', 'thermal', 'lifesupport', 'communications', 'energy', 'storage', 'medical', 'sleeping', 'exercise', 'food', 'water', 'safety', 'recreation', 'research', 'maintenance'];
let gridWidth = 5;
let gridHeight = 5;

// تشغيل الكود عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    setupHabitatConfiguration();
    initializeGrid();
    setupDragAndDrop();
    setupButtons();
    setupEnvironmentSelector();
    updateEnvironmentDisplay();
    
    // تطبيق البيئة الافتراضية
    document.body.setAttribute('data-environment', currentEnvironment);
    
    // تحديث الوحدات المتاحة في البداية
    updateSelectedFunctions();
    updateAvailableModules();
    setupModuleInfoPanel();
});

// إعداد تكوين المسكن
function setupHabitatConfiguration() {
    // أزرار اختيار الحجم
    document.querySelectorAll('.size-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.size-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            habitatSize = this.dataset.size;
            updateGridSize();
            toggleCustomDimensions();
        });
    });
    
    
    // أزرار اختيار الوظائف
    document.querySelectorAll('input[name="functions"]').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateSelectedFunctions();
            updateAvailableModules();
        });
    });
    
    // زر الأبعاد المخصصة
    document.getElementById('applyCustomSize').addEventListener('click', function() {
        const width = parseInt(document.getElementById('customWidth').value);
        const height = parseInt(document.getElementById('customHeight').value);
        if (width >= 3 && width <= 20 && height >= 3 && height <= 20) {
            gridWidth = width;
            gridHeight = height;
            initializeGrid();
            
            // تحديث الشبكة التفاعلية في العرض ثلاثي الأبعاد
            if (typeof updateInteractiveGrid === 'function') {
                updateInteractiveGrid();
            }
        }
    });
    
    // زر المتابعة
    document.getElementById('proceedToDesign').addEventListener('click', function() {
        document.body.classList.add('design-phase');
        document.querySelector('.habitat-setup').style.display = 'none';
        document.querySelector('.environment-selector').style.display = 'block';
        document.querySelector('.main-content').style.display = 'flex';
        document.querySelector('.results').style.display = 'block';
        
        // تحديث الوحدات المتاحة عند الانتقال لمرحلة التصميم
        updateSelectedFunctions();
        updateAvailableModules();
        setupModuleInfoPanel();
    });
}

// تحديث حجم الشبكة
function updateGridSize() {
    const sizeMap = {
        small: { width: 5, height: 5 },
        medium: { width: 8, height: 8 },
        large: { width: 12, height: 12 }
    };
    
    if (habitatSize !== 'custom') {
        const size = sizeMap[habitatSize];
        gridWidth = size.width;
        gridHeight = size.height;
        initializeGrid();
        
        // تحديث الشبكة التفاعلية في العرض ثلاثي الأبعاد
        if (typeof updateInteractiveGrid === 'function') {
            updateInteractiveGrid();
        }
    }
}

// عرض/إخفاء الأبعاد المخصصة
function toggleCustomDimensions() {
    const customDiv = document.getElementById('customDimensions');
    if (habitatSize === 'custom') {
        customDiv.style.display = 'flex';
    } else {
        customDiv.style.display = 'none';
    }
}

// تحديث الوظائف المختارة
function updateSelectedFunctions() {
    selectedFunctions = Array.from(document.querySelectorAll('input[name="functions"]:checked'))
        .map(cb => cb.value);
}

// تحديث الوحدات المتاحة
function updateAvailableModules() {
    document.querySelectorAll('.module').forEach(module => {
        const moduleType = module.dataset.type;
        if (selectedFunctions.includes(moduleType)) {
            module.style.display = 'flex';
            module.style.opacity = '1';
            module.style.transform = 'translateY(0)';
        } else {
            module.style.display = 'none';
        }
    });
    
    // إضافة تأثير انزلاق سلس للوحدات الظاهرة
    setTimeout(() => {
        document.querySelectorAll('.module[style*="display: flex"]').forEach((module, index) => {
            module.style.animation = `slideInModule 0.4s ease ${index * 0.1}s both`;
        });
    }, 50);
}

// إعداد لوحة معلومات الوحدة
function setupModuleInfoPanel() {
    document.querySelectorAll('.module').forEach(module => {
        module.addEventListener('mouseenter', function() {
            showModuleInfo(this.dataset.type);
        });
        
        module.addEventListener('mouseleave', function() {
            hideModuleInfo();
        });
    });
}

// عرض معلومات الوحدة
function showModuleInfo(moduleType) {
    const panel = document.getElementById('moduleInfoPanel');
    const properties = moduleProperties[moduleType];
    
    if (properties) {
        document.getElementById('moduleInfoTitle').textContent = moduleType.charAt(0).toUpperCase() + moduleType.slice(1);
        document.getElementById('moduleDescription').textContent = properties.description;
        document.getElementById('moduleWeight').textContent = properties.weight + ' kg';
        document.getElementById('modulePower').textContent = (properties.power > 0 ? '+' : '') + properties.power + ' W';
        document.getElementById('moduleFunction').textContent = properties.required ? 'Essential - ضروري' : 'Optional - اختياري';
        
        panel.style.display = 'block';
    }
}

// إخفاء معلومات الوحدة
function hideModuleInfo() {
    document.getElementById('moduleInfoPanel').style.display = 'none';
}

// إنشاء الشبكة
function initializeGrid() {
    const grid = document.getElementById('designGrid');
    grid.innerHTML = '';
    
    const totalCells = gridWidth * gridHeight;
    
    // تحديث حجم الشبكة
    grid.style.gridTemplateColumns = `repeat(${gridWidth}, 1fr)`;
    grid.style.gridTemplateRows = `repeat(${gridHeight}, 1fr)`;
    
    for (let i = 0; i < totalCells; i++) {
        const cell = document.createElement('div');
        cell.classList.add('grid-cell');
        cell.dataset.index = i;
        
        // إضافة أحداث السحب والإفلات للخلايا
        cell.addEventListener('dragover', handleDragOver);
        cell.addEventListener('drop', handleDrop);
        cell.addEventListener('dragleave', handleDragLeave);
        
        grid.appendChild(cell);
    }
}

// إعداد السحب والإفلات
function setupDragAndDrop() {
    const modules = document.querySelectorAll('.module');
    
    modules.forEach(module => {
        module.addEventListener('dragstart', handleDragStart);
        module.addEventListener('dragend', handleDragEnd);
    });
}

// إعداد الأزرار
function setupButtons() {
    document.getElementById('evaluateBtn').addEventListener('click', evaluateDesign);
    document.getElementById('clearBtn').addEventListener('click', clearGrid);
}

// إعداد اختيار البيئة
function setupEnvironmentSelector() {
    const environmentBtns = document.querySelectorAll('.environment-btn');
    
    environmentBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // إزالة التحديد من جميع الأزرار
            environmentBtns.forEach(b => b.classList.remove('active'));
            
            // تحديد الزر المضغوط
            this.classList.add('active');
            
            // تغيير البيئة الحالية
            currentEnvironment = this.dataset.env;
            
            // تطبيق التغيير البصري للبيئة
            document.body.setAttribute('data-environment', currentEnvironment);
            
            // تحديث العرض
            updateEnvironmentDisplay();
            
            // إعادة إنشاء الشبكة بالحجم الجديد
            clearGrid();
            initializeGrid();
            setupDragAndDrop();
            
            // تحديث العرض ثلاثي الأبعاد
            if (typeof update3DEnvironment === 'function') {
                update3DEnvironment(currentEnvironment);
            }
            
        });
    });
}

// تحديث عرض معلومات البيئة
function updateEnvironmentDisplay() {
    const env = environmentParameters[currentEnvironment];
    
    document.getElementById('gravityValue').textContent = 
        env.gravity === 0 ? '0 g' : `${env.gravity} m/s²`;
    
    document.getElementById('weightLimitValue').textContent = 
        env.weightLimit === Infinity ? '∞ kg' : `${env.weightLimit} kg`;
    
    document.getElementById('powerFactorValue').textContent = `${env.powerFactor}x`;
    
    // حساب منطقة البناء بناءً على الحجم المختار في صفحة الإعداد
    let buildArea;
    if (habitatSize === 'custom') {
        buildArea = `${gridWidth}x${gridHeight}`;
    } else {
        const sizeMap = {
            small: '5x5',
            medium: '8x8', 
            large: '12x12'
        };
        buildArea = sizeMap[habitatSize] || '5x5';
    }
    
    document.getElementById('buildAreaValue').textContent = buildArea;
}

// بداية السحب
function handleDragStart(e) {
    draggedElement = e.target;
    e.target.classList.add('dragging');
    
    // تخزين بيانات الوحدة
    e.dataTransfer.setData('text/plain', JSON.stringify({
        type: e.target.dataset.type,
        weight: e.target.dataset.weight,
        power: e.target.dataset.power
    }));
}

// نهاية السحب
function handleDragEnd(e) {
    e.target.classList.remove('dragging');
    draggedElement = null;
}

// السحب فوق الخلية
function handleDragOver(e) {
    e.preventDefault();
    if (!e.target.classList.contains('occupied')) {
        e.target.classList.add('drag-over');
    }
}

// مغادرة منطقة الإفلات
function handleDragLeave(e) {
    e.target.classList.remove('drag-over');
}

// الإفلات
function handleDrop(e) {
    e.preventDefault();
    e.target.classList.remove('drag-over');
    
    if (e.target.classList.contains('occupied')) {
        return; // لا يمكن الإفلات في خلية محتلة
    }
    
    try {
        const moduleData = JSON.parse(e.dataTransfer.getData('text/plain'));
        
        // إضافة الوحدة إلى الخلية
        placeModule(e.target, moduleData);
        
    } catch (error) {
        console.error('خطأ في إفلات الوحدة:', error);
    }
}

// وضع الوحدة في الخلية
function placeModule(cell, moduleData) {
    cell.classList.add('occupied');
    cell.innerHTML = moduleIcons[moduleData.type];
    cell.dataset.moduleType = moduleData.type;
    cell.dataset.moduleWeight = moduleData.weight;
    cell.dataset.modulePower = moduleData.power;
    
    // إضافة إمكانية إزالة الوحدة بالنقر المزدوج
    cell.addEventListener('dblclick', function() {
        removeModule(cell);
    });
    
    // تحديث قائمة الوحدات المحتلة
    placedModules.push({
        cell: cell,
        type: moduleData.type,
        cellIndex: parseInt(cell.dataset.index),
        weight: parseInt(moduleData.weight),
        power: parseInt(moduleData.power)
    });
    
    // تحديث العرض ثلاثي الأبعاد
    if (typeof update3DModules === 'function') {
        update3DModules();
    }
}

// إزالة الوحدة
function removeModule(cell) {
    cell.classList.remove('occupied');
    cell.innerHTML = '';
    delete cell.dataset.moduleType;
    delete cell.dataset.moduleWeight;
    delete cell.dataset.modulePower;
    
    // إزالة من قائمة الوحدات المحتلة
    placedModules = placedModules.filter(module => module.cell !== cell);
    
    // تحديث العرض ثلاثي الأبعاد
    if (typeof update3DModules === 'function') {
        update3DModules();
    }
}

// تقييم التصميم
function evaluateDesign() {
    if (placedModules.length === 0) {
        showReport('لم يتم وضع أي وحدات في التصميم', 'error');
        return;
    }
    
    const env = environmentParameters[currentEnvironment];
    
    // حساب الوزن والطاقة والتكلفة مع معاملات البيئة
    let totalWeight = 0;
    let totalPower = 0;
    let totalCost = 0;
    let moduleCounts = {};
    
    placedModules.forEach(module => {
        // تطبيق معامل الجاذبية على الوزن
        const adjustedWeight = env.gravity === 0 ? module.weight : module.weight * (env.gravity / 9.8);
        totalWeight += adjustedWeight;
        
        // تطبيق معامل الطاقة
        const adjustedPower = module.power * env.powerFactor;
        totalPower += adjustedPower;
        
        // حساب التكلفة (مع معامل تكلفة البيئة)
        const moduleCost = moduleProperties[module.type]?.cost || 0;
        const adjustedCost = moduleCost * (env.costFactor || 1);
        totalCost += adjustedCost;
        
        moduleCounts[module.type] = (moduleCounts[module.type] || 0) + 1;
    });
    
    // حساب مدة البقاء على قيد الحياة
    const survivalDuration = calculateSurvivalDuration(moduleCounts, env);
    
    // فحص الوحدات المطلوبة
    const requiredModules = ['sleeping', 'kitchen', 'lifesupport'];
    const missingModules = [];
    
    requiredModules.forEach(requiredType => {
        const hasModule = placedModules.some(module => module.type === requiredType);
        if (!hasModule) {
            const names = {
                sleeping: 'وحدة النوم (Sleeping Unit)',
                //kitchen: 'المطبخ (Kitchen)',
                lifesupport: 'دعم الحياة (Life Support)'
            };
            missingModules.push(names[requiredType]);
        }
    });
    
    // إنشاء التقرير المحدث
    generateEnvironmentReport(totalWeight, totalPower, totalCost, missingModules, survivalDuration, env);
}

// حساب مدة البقاء على قيد الحياة
function calculateSurvivalDuration(moduleCounts, env) {
    // التحقق من وجود الوحدات الأساسية
    if (!moduleCounts.lifesupport || !moduleCounts.energy || !moduleCounts.sleeping) {
        return 0; // لا يمكن البقاء بدون الوحدات الأساسية
    }
    
    // حساب عوامل البقاء
    const oxygenFactor = moduleCounts.lifesupport * env.oxygenEfficiency;
    const powerFactor = moduleCounts.energy * env.powerEfficiency;
    const comfortFactor = moduleCounts.sleeping * 0.5;
    const foodFactor = moduleCounts.kitchen ? moduleCounts.kitchen * 0.3 : 0.1; // قليل بدون مطبخ
    const storageFactor = moduleCounts.storage ? moduleCounts.storage * 0.2 : 0.05;
    
    // المدة الأساسية للبيئة
    let baseDuration = env.survivalBase;
    
    // تطبيق العوامل
    const totalFactor = oxygenFactor + powerFactor + comfortFactor + foodFactor + storageFactor;
    
    // حساب المدة النهائية
    const finalDuration = Math.round(baseDuration * totalFactor);
    
    return Math.max(0, finalDuration); // لا تقل عن صفر
}

// إنشاء تقرير التقييم مع معاملات البيئة
function generateEnvironmentReport(totalWeight, totalPower, totalCost, missingModules, survivalDuration, env) {
    let reportHTML = '<div class="report-summary">';
    
    // معلومات البيئة
    reportHTML += `
        <div class="report-section environment-section">
            <h4>🌍 البيئة الحالية - Current Environment: ${env.name}</h4>
            <div class="env-stats">
                <span>الجاذبية: ${env.gravity === 0 ? '0 g' : env.gravity + ' m/s²'}</span> |
                <span>معامل الطاقة: ${env.powerFactor}x</span> |
                <span>الحد الأقصى للوزن: ${env.weightLimit === Infinity ? '∞' : env.weightLimit + ' kg'}</span>
            </div>
        </div>
    `;
    
    // مدة البقاء
    reportHTML += `
        <div class="report-section survival-section">
            <h4>🕐 مدة البقاء المقدرة - Survival Duration</h4>
            <div class="survival-duration">
                <strong>${survivalDuration} يوم</strong>
                ${survivalDuration >= 365 ? '(ممتاز - طويل المدى)' : 
                  survivalDuration >= 180 ? '(جيد - متوسط المدى)' :
                  survivalDuration > 0 ? '(قصير المدى)' : '(غير قابل للحياة)'}
            </div>
        </div>
    `;
    
    // معلومات أساسية
    reportHTML += `
        <div class="report-section stats-section">
            <div class="report-item">
                <strong>إجمالي الوزن - Total Weight:</strong> ${Math.round(totalWeight)} kg
                ${env.weightLimit !== Infinity && totalWeight > env.weightLimit ? ' ⚠️ تجاوز الحد الأقصى' : ' ✅'}
            </div>
            <div class="report-item">
                <strong>استهلاك الطاقة - Power Consumption:</strong> ${Math.round(totalPower)} W
            </div>
            <div class="report-item cost-highlight">
                <strong>💰 التكلفة المتوقعة - Expected Cost:</strong> 
                <span class="cost-amount">${formatCurrency(totalCost)}</span>
            </div>
            <div class="report-item">
                <strong>عدد الوحدات - Number of Modules:</strong> ${placedModules.length}
            </div>
        </div>
    `;
    
    // حالة التصميم
    let status = 'success';
    let statusMessage = '';
    
    if (missingModules.length > 0) {
        status = 'error';
        statusMessage = `<div class="report-item"><strong>وحدات مفقودة - Missing Modules:</strong><br>`;
        statusMessage += missingModules.map(module => `• ${module}`).join('<br>');
        statusMessage += '</div>';
    } else if (env.weightLimit !== Infinity && totalWeight > env.weightLimit) {
        status = 'error';
        statusMessage = `<div class="report-item"><strong>خطأ:</strong> تجاوز الحد الأقصى للوزن بـ ${Math.round(totalWeight - env.weightLimit)} kg</div>`;
    } else if (totalPower > 0) {
        status = 'warning';
        statusMessage = `<div class="report-item"><strong>تحذير:</strong> المسكن يحتاج إلى ${Math.round(totalPower)}W من الطاقة الإضافية</div>`;
    } else {
        statusMessage = '<div class="report-item"><strong>ممتاز!</strong> التصميم مكتمل ومتوازن</div>';
    }
    
    reportHTML += statusMessage;
    
    // تفاصيل الوحدات
    reportHTML += '<div class="report-item"><strong>تفاصيل الوحدات - Module Details:</strong><br>';
    const moduleCount = {};
    placedModules.forEach(module => {
        moduleCount[module.type] = (moduleCount[module.type] || 0) + 1;
    });
    
    Object.keys(moduleCount).forEach(type => {
        const names = {
            sleeping: 'وحدة النوم - Sleeping Unit',
            kitchen: 'المطبخ - Kitchen',
            storage: 'المخزن - Storage',
            lifesupport: 'دعم الحياة - Life Support',
            energy: 'الطاقة - Energy',
            waste: 'إدارة النفايات - Waste Management',
            thermal: 'التحكم الحراري - Thermal Control',
            communications: 'الاتصالات - Communications',
            medical: 'الطب - Medical',
            exercise: 'اللياقة - Exercise',
            food: 'إنتاج الطعام - Food Production',
            water: 'إدارة المياه - Water Management',
            safety: 'الأمان والطوارئ - Safety & Emergency',
            recreation: 'الترفيه - Recreation',
            research: 'البحوث - Research Lab',
            maintenance: 'الصيانة - Maintenance'
        };
        reportHTML += `• ${names[type] || type}: ${moduleCount[type]} وحدة<br>`;
    });
    
    reportHTML += '</div></div>';
    
    // تحديد الحالة النهائية
    if (survivalDuration === 0) {
        status = 'error';
    }
    
    showReport(reportHTML, status);
}

// تنسيق العملة
function formatCurrency(amount) {
    if (amount >= 1000000000) {
        return `$${(amount / 1000000000).toFixed(1)}B`; // مليار
    } else if (amount >= 1000000) {
        return `$${(amount / 1000000).toFixed(1)}M`; // مليون
    } else if (amount >= 1000) {
        return `$${(amount / 1000).toFixed(0)}K`; // ألف
    } else {
        return `$${amount.toFixed(0)}`;
    }
}

// عرض التقرير
function showReport(content, type = 'info') {
    const reportElement = document.getElementById('report');
    reportElement.innerHTML = content;
    reportElement.className = `report ${type}`;
}

// مسح الشبكة
function clearGrid() {
    if (confirm('هل أنت متأكد من مسح جميع الوحدات؟')) {
        const cells = document.querySelectorAll('.grid-cell');
        cells.forEach(cell => {
            cell.classList.remove('occupied');
            cell.innerHTML = '';
            delete cell.dataset.moduleType;
            delete cell.dataset.moduleWeight;
            delete cell.dataset.modulePower;
        });
        
        placedModules = [];
        showReport('تم مسح جميع الوحدات. ابدأ بوضع الوحدات الجديدة.', 'info');
        
    
        if (typeof window.update3DView === 'function') {
            window.update3DView();
        }
    }
}

// إضافة تأثيرات بصرية للتفاعل
document.addEventListener('DOMContentLoaded', function() {
    // تأثيرات hover للوحدات
    const modules = document.querySelectorAll('.module');
    modules.forEach(module => {
        module.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px) scale(1.02)';
        });
        
        module.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
});