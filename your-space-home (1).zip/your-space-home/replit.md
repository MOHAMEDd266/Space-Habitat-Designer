# Space Habitat Designer - محاكي تصميم المساكن الفضائية

## Overview

This project is a bilingual (Arabic/English) web-based space habitat design simulator that allows users to create and plan space station layouts through an interactive drag-and-drop interface. The application enables users to place various modules (sleeping quarters, kitchen, storage, life support, energy) on a grid-based design canvas and provides real-time feedback on resource requirements and design constraints.

The simulator is built as a client-side application focusing on educational and planning purposes for space habitat design, with emphasis on resource management (weight and power consumption) and spatial planning.

## Recent Changes

### September 9, 2025 - Latest Update
- **Environment-Responsive Design**: Added dynamic visual themes for all four space environments (LEO, Mars, Moon, Deep Space)
- **Enhanced 2D Grid System**: Environment-specific colors, patterns, and visual effects for the design grid
- **Advanced 3D Visualization**: Significantly enlarged and enhanced 3D view with improved lighting system
- **Realistic Module Architecture**: Larger modules (2.4x2.4m) with detailed walls, windows, LED lighting strips, and metallic flooring
- **Professional Lighting Setup**: Multiple light sources including ambient, directional, fill, and spot lighting for enhanced realism
- **Environmental Immersion**: Animated stars for deep space, sand dunes for Mars, crater patterns for Moon, and orbital effects for LEO
- **Smooth Module Scrolling**: Professional scrollbar design with gradient colors and staggered slide-in animations
- **Interactive Visual Feedback**: Enhanced hover effects, lighting animations, and responsive design optimizations

### September 9, 2025 - Earlier Updates
- **Comprehensive Functional Requirements Added**: Implemented complete habitat setup with size, shape, and function selection
- **Habitat Configuration System**: Added user input for habitat size (small/medium/large/custom), shape (cube/cylinder/sphere/modular), and essential functions
- **Complete Module System**: Added 15 comprehensive module types covering all essential space habitat needs
- **Food Production System**: Added hydroponic farming and food production module with realistic 3D cultivation systems
- **Water Management**: Complete water recycling and purification system with tanks, filters, and distribution
- **Safety & Emergency**: Comprehensive safety systems including fire suppression, first aid, and evacuation equipment
- **Recreation & Wellness**: Mental health and entertainment facilities with relaxation areas and activities
- **Research Laboratory**: Scientific research capabilities with microscopes, computers, and experimental equipment
- **Maintenance Workshop**: Complete repair and maintenance facility with tools and spare parts storage
- **Advanced 3D Visualization**: Enhanced realistic 3D models with detailed furniture and equipment for all 15 module types
- **Interactive Module Information**: Added hover tooltips with detailed specifications and descriptions for each module
- **Progressive Workflow**: Created guided setup process from habitat configuration to environment selection to design implementation
- **Responsive Interface**: Comprehensive UI supporting both Arabic and English with professional space industry styling

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Pure HTML/CSS/JavaScript**: Single-page application without frameworks, prioritizing simplicity and educational accessibility
- **Dual-View System**: Toggle between 2D grid-based design and immersive 3D visualization
- **Grid-based Design Canvas**: 10x10 grid system for modular placement and spatial planning
- **Drag-and-Drop Interface**: Native HTML5 drag-and-drop API for intuitive module placement
- **3D Visualization Engine**: Three.js integration for realistic space habitat modeling
- **Real-time Resource Tracking**: Dynamic calculation and display of weight, power consumption, and design validation

### Module System (15 Complete Module Types)
#### Core Life Support Modules
- **Sleeping**: Rest areas with beds and personal space for crew quarters
- **Kitchen**: Food preparation and dining facilities with cooking equipment
- **Storage**: Equipment and supplies storage with organized compartments
- **Life Support**: Oxygen generation and air recycling systems
- **Energy**: Power generation, batteries, and electrical distribution

#### Specialized Systems Modules  
- **Waste Management**: Recycling and waste processing with separation systems
- **Thermal Control**: Temperature regulation and climate control systems
- **Communications**: Earth communication systems with satellite dishes and radio equipment
- **Medical**: Complete medical facility with examination beds, equipment, and pharmaceuticals
- **Exercise**: Fitness equipment and physical wellness facilities

#### Advanced Facility Modules
- **Food Production**: Hydroponic farming systems with grow lights and nutrient management
- **Water Management**: Water recycling, purification, filtration, and distribution systems
- **Safety & Emergency**: Fire suppression, first aid, evacuation equipment, and safety protocols
- **Recreation**: Mental wellness facilities with entertainment, books, and relaxation areas  
- **Research Laboratory**: Scientific research with microscopes, computers, and experimental equipment
- **Maintenance**: Workshop with tools, spare parts, and repair equipment for habitat upkeep

#### Module Properties
- **Resource Properties**: Each module has defined weight and power characteristics
- **Placement Validation**: Grid-based collision detection and placement rules  
- **Visual Feedback**: Icon-based representation with immediate visual state changes
- **Detailed Specifications**: Hover information showing weight, power, function, and descriptions

### State Management
- **Client-side Storage**: All design state maintained in browser memory through JavaScript variables
- **Session-based Persistence**: No database or permanent storage - designs exist only during active session
- **Modular Data Structure**: Object-oriented approach to module properties and placement tracking

### 3D Visualization System (The Sims Style)
- **Three.js Integration**: Advanced 3D graphics library for WebGL rendering
- **Isometric Camera System**: OrthographicCamera with fixed isometric view like The Sims
- **Cartoonish Module Designs**: Simple, colorful room-style modules with flat shading
- **Bright Lighting**: Simple, cheerful lighting system without complex shadows
- **The Sims Aesthetic**: Bright colors, simple shapes, and friendly cartoon-like appearance
- **Room-Based Modules**: Each module designed as a simple room with furniture and equipment
- **Colorful Materials**: MeshLambertMaterial with flatShading for cartoon-like appearance

### Localization Strategy
- **Bilingual Support**: Simultaneous Arabic (RTL) and English (LTR) text display
- **CSS Direction Handling**: RTL layout support with appropriate text alignment
- **Dual Language Headers**: Both Arabic and English titles for accessibility

## External Dependencies

### Core Technologies
- **HTML5**: Semantic markup and drag-and-drop API support
- **CSS3**: Grid layouts, flexbox, gradients, and RTL text direction
- **Vanilla JavaScript**: ES6+ features for DOM manipulation and event handling
- **Three.js r128**: 3D graphics library via CDN for WebGL rendering

### Browser APIs
- **Drag and Drop API**: Native HTML5 drag-and-drop for module placement
- **DOM Events**: Mouse and touch interaction handling
- **CSS Grid**: Grid-based layout system for design canvas
- **WebGL**: Hardware-accelerated 3D graphics rendering

### 3D Assets (The Sims Style)
- **Simple Geometry**: Basic Three.js primitives arranged as room furniture
- **Cartoon Materials**: MeshLambertMaterial with flatShading and bright colors
- **Cheerful Lighting**: Simple ambient and directional lights for bright, friendly appearance
- **Room Design**: Each module contains furniture and equipment appropriate to its function
- **Color-Coded Rooms**: Pink (sleeping), yellow (kitchen), green (storage), teal (life support), orange (energy)

### Assets
- **Unicode Emojis**: Module icons using standard emoji characters (🛏️, 🍳, 📦, 💨, 🔋)
- **Web Fonts**: Arial fallback font family for cross-platform compatibility

Note: This application uses Three.js as the only external dependency (loaded via CDN), maintaining browser-only functionality with no server-side components. All 3D models are generated procedurally using simple geometric primitives styled like The Sims game for a friendly, approachable aesthetic.